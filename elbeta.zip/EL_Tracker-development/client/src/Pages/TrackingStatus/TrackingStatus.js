import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { trackingStatus, resetTrackingStatus } from "../../features/trackingStatusSlice";
import { Link, useParams } from "react-router-dom";
import HeaderNavbar from "../../component/HeaderNavbar";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import moment from "moment";
import "./TrackingStatus.css";

const TrackingStatus = () => {
  const dispatch = useDispatch();
  const { poDoc } = useParams();

  const { trackingStatusData, loading, error } = useSelector(
    (state) => state.trackingStatus
  );


  const trackingOb = trackingStatusData?.[0] || {};
  console.log(trackingOb);


  console.log(trackingOb);
  

  useEffect(() => {
    dispatch(trackingStatus(poDoc));
    return () => {
      dispatch(resetTrackingStatus());
    };
  }, [dispatch, poDoc]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error fetching tracking status: {error}</p>;


  return (
    <div className="main-tracking-status">
      <HeaderNavbar />
      <div className="status">
        <div className="status-overlay">
          <div className="status-inner">
            <div className="container-fluid">
              <div className="row m-2 d-flex justify-content-evenly">
                {/* Timeline Section */}
                <div className="col-md-5 my-card p-3">
                  <div className="timeline">
                    <div className="timeline-item">
                      <div className="icon material-readiness-date">📄</div>
                      <div className="text material-readiness-date-text">
                        PO received date
                        <br />
                      </div>
                    </div>
                    <p className="date-style">
                      {moment(trackingOb.po_received_date).format("DD/MM/YYYY")}
                    </p>

                    <div className="timeline-item">
                      <div className="icon planned-for-picking">✅</div>
                      <div className="text planned-for-picking-text">
                        Planned for picking
                      </div>
                    </div>
                    <p className="date-style">
                      {moment(trackingOb.planned_for_picking).format(
                        "DD/MM/YYYY"
                      )}
                    </p>

                    <div className="timeline-item">
                      <div className="icon picked-from-vendor">📦</div>
                      <div className="text picked-from-vendor-text">
                        Picked from vendor location
                      </div>
                    </div>

                    <p className="date-style">
                      {moment(trackingOb.inDateLT).format("DD/MM/YYYY")}
                    </p>


                    {trackingOb.mode_of_delivery === "Direct Delivery" && (
                      <>
                        <div className="timeline-item">
                          <div className="icon picked-from-vendor">📦</div>
                          <div className="text picked-from-vendor-text">
                            Dispatch from vendor location
                          </div>
                        </div>

                        <p className="date-style">
                          {moment(trackingOb.inDateLT).format("DD/MM/YYYY")}
                        </p>
                      </>
                    )}



                    {/*when milk run then i have show */}
                    {trackingOb.mode_of_delivery === "Milk Run" && (
                      <>
                        <div className="timeline-item">
                          <div className="icon received-at-el-cross-dock">
                            📥
                          </div>
                          <div className="text received-at-el-cross-dock-text">
                            Received at EL cross-dock
                          </div>
                        </div>
                        <p className="date-style">
                          {moment(trackingOb.inDateLT).format("DD/MM/YYYY")}
                        </p>

                        <div className="timeline-item">
                          <div className="icon dispatched-from-el-cross-dock">
                            🚚
                          </div>
                          <div className="text dispatched-from-el-cross-dock-text">
                            Dispatched from EL cross-dock
                          </div>
                        </div>
                        <p className="date-style">
                          {moment(trackingOb.transDateLT).format("DD/MM/YYYY")}
                        </p>
                      </>
                    )}

                    <div className="timeline-item">
                      <div className="icon delivered-at-customer">🚛</div>
                      <div className="text delivered-at-customer-text">
                        Delivered at customer location
                      </div>
                    </div>
                    <p className="date-style">
                      {moment(trackingOb.transDateLT).format("DD/MM/YYYY")}
                    </p>
                  </div>
                </div>

   

                {/* Details Section */}
                <div className="col-md-6 my-card p-4">
                  <h4>
                    <b>Details:</b>
                  </h4>
                  <br />
                  <div className="row">
                    <div className="col-sm-6" style={{ color: "#f59905" }}>
                      <h6>
                        <b>PO:</b> {poDoc}
                      </h6>
                      <h6>
                        <b>PO Date:</b>{" "}
                        {moment(trackingOb.po_received_date).format(
                          "DD/MM/YYYY"
                        )}
                      </h6>
                    </div>
                  </div>
                  <hr />
                  <br />
                  <div className="row text-success">
                    <div className="col-sm-12">
                      <h6>
                        <b>Vendor:</b> {trackingOb.vendorName}
                      </h6>
                      <h6>
                        <b>Pickup Location:</b> {trackingOb.vendorAddress}
                      </h6>
                    </div>
                  </div>
                  <hr />
                  <br />
                  <div className="row">
                    <div className="col-sm-6" style={{ color: "#003C78" }}>
                      <h6>
                        <b>Delivery type:</b> {trackingOb.mode_of_delivery}
                      </h6>
                      <h6>
                        <b>Delivery plant:</b> {trackingOb.delivery_plant}
                      </h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Section */}
          <div className="footer">
            <p style={{ fontSize: "13px" }} className="text-black">
              &copy; 2024, Emirates Logistics | Developed By{" "}
              <a
                href="http://globuslabs.com"
                className="text-dark"
                target="_blank"
                rel="noopener noreferrer"
              >
                Globus Labs
              </a>
            </p>
          </div>
        </div>

        {/* Floating Search Button */}
        <Link to="/" className="fab">
          <FontAwesomeIcon icon={faSearch} />
        </Link>
        </div>  
        </div>

  );
};

export default TrackingStatus;
