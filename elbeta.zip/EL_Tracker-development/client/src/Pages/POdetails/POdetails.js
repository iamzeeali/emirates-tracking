import {
  Container,
  Form,
  Button,
  Table,
  Pagination,
  Row,
  Col,
} from "react-bootstrap";
import {
  AiOutlineSearch,
} from "react-icons/ai";
import moment from "moment";
import HeaderNavbar from "../../component/HeaderNavbar";
import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

const columns = [
  { id: "po_received_date", label: "PO Received Date", minWidth: 120 },
  { id: "planned_for_picking", label: "Planned Date", minWidth: 120 },
  { id: "inDateLT", label: "Picked Date", minWidth: 120 },
  { id: "inDateLT", label: "EL Received", minWidth: 120 },
  { id: "transDateLT", label: "Dispatched Date", minWidth: 120 },
  { id: "transDateLT", label: "Delivery Date", minWidth: 120 },
  { id: "deliveryType", label: "Delivery Type", minWidth: 150 },
  { id: "deliveryPlant", label: "Delivery Plant", minWidth: 120 },
];

const POdetails = () => {
  const location = useLocation();
  const { poDoc } = location.state || {};
  const [poDetails, setPoDetails] = useState([]);
  const [deliveryPlants, setDeliveryPlants] = useState(["All"]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const rowsPerPage = 15;
  const [selectedPlant, setSelectedPlant] = useState("All");
  const [searchValue, setSearchValue] = useState(poDoc || "");

 

  useEffect(() => {
    if (poDoc) {
      fetchPoDetails(poDoc);
    }
  }, [poDoc]);


  const fetchPoDetails = async (poNumber) => {
    try {
      const response = await axios.get(
        `http://localhost:1433/v1/api/po/poDetail?poDoc=${poNumber}`
      );
      
      // Check for a successful status code
      if (response.status < 200 || response.status >= 300) {
        throw new Error("Failed to fetch data");
      }
  
      const data = response.data; // No need for `await` here, as `data` is already resolved
  
      console.log(data, "shshsh");
  
      // Update state with fetched data
      setPoDetails(data);
  
      const uniquePlants = ["All", ...new Set(data.map((row) => row.deliveryPlant))];
      setDeliveryPlants(uniquePlants);
  
      setPage(1);
      setTotalPages(Math.ceil(data.length / rowsPerPage));
    } catch (error) {
      console.error("Error fetching PO details:", error);
    }
  };
  
  const handleSearch = () => {
    if (searchValue.trim()) {
      fetchPoDetails(searchValue);
    }
  };


  const handlePlantChange = (e) => {
    setSelectedPlant(e.target.value);
    setPage(1);
  };


  const filteredRows =
    selectedPlant === "All"
      ? poDetails
      : poDetails.filter((row) => row.deliveryPlant === selectedPlant);

  const paginatedRows = filteredRows.slice(
    (page - 1) * rowsPerPage,
    page * rowsPerPage
  );
  


  return (
    <Container fluid className="p-0">
      <HeaderNavbar />
      <div className="container">
        <Container fluid className="p-2">
          <Row className="justify-content-start mt-2 mb-2">
            <Col xs={8} sm={6} md={6} lg={6}>
              <Form className="d-flex">
                <Form.Control
                  type="search"
                  placeholder={searchValue || "Enter PO Number ..."}
                  className="me-2"
                  style={{ fontSize: "13px" }}
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                />
                <Button
                  variant="outline-warning"
                  style={{ backgroundColor: "#f90", borderColor: "#f90" }}
                  onClick={handleSearch}
                >
                  <AiOutlineSearch style={{ color: "white" }} />
                </Button>
              </Form>
            </Col>
            <Col xs={4} sm={3} md={6} lg={6}>
              <Form.Select onChange={handlePlantChange} value={selectedPlant}>
                {deliveryPlants.map((plant) => (
                  <option key={plant} value={plant}>
                    {plant}
                  </option>
                ))}
              </Form.Select>
            </Col>
          </Row>

          <div className="d-flex justify-content-between align-items-center flex-wrap p-2">
            <h6 style={{ fontSize: "14px", color: "#003c78" }}>
              Vendor Name: <span style={{ color: "#000000" }}>{poDetails[0]?.vendorName}</span>
            </h6>
            <h6 style={{ fontSize: "14px", color: "#000000" }}>
              <i className="fa fa-hashtag"></i> Selected PO: {poDoc}
              <br />
              <i className="fa fa-hashtag"></i> Count: {filteredRows.length}
            </h6>
          </div>

          <div
            style={{
              maxHeight: "60vh",
              minHeight: "60vh",
              maxWidth: "100%",
              overflow: "auto",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Table responsive bordered hover>
              <thead style={{ position: "sticky", top: 0, zIndex: 1 }}>
                <tr>
                  {columns.map((column) => (
                    <th
                      key={column.id}
                      style={{
                        minWidth: column.minWidth,
                        fontWeight: "700",
                        textAlign: "center",
                        background: "#003c78",
                        color: "white",
                        fontSize: "12px",
                      }}
                    >
                      {column.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {paginatedRows.length > 0 ? (
                  paginatedRows.map((row, index) => (
                    <tr key={index}>
                      {columns.map((column) => {
                        const value = row[column.id];
                        return (
                          <td
                            key={column.id}
                            style={{ fontSize: "12px", textAlign: "center" }}
                          >
                            {["po_received_date", "planned_for_picking", "inDateLT", "transDateLT"].includes(column.id)
                              ? moment(value).format("DD/MM/YYYY")
                              : value}
                          </td>
                        );
                      })}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={columns.length}
                      style={{
                        textAlign: "center",
                        fontSize: "14px",
                        fontWeight: "500",
                      }}
                    >
                      No data found for the selected Delivery Plant.
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          </div>

          <Pagination className="justify-content-end mt-2">
            <Pagination.Prev
              onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
              disabled={page === 1}
            />
            <Pagination.Item>{page}</Pagination.Item>
            <Pagination.Next
              onClick={() => setPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={page === totalPages}
            />
          </Pagination>
        </Container>
      </div>
    </Container>
  );
};

export default POdetails;
