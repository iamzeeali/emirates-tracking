import React, { useState } from "react";
import truckgif from "../../assets/truck2gif.gif";
import { TextField, InputAdornment } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import HeaderNavbar from "../../component/HeaderNavbar";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSitemap } from "@fortawesome/free-solid-svg-icons";
import { useDispatch } from 'react-redux';
import { setAlert } from "../../features/alertSlice"
import './Tracking.css'

const Tracking = () => {
  const dispatch = useDispatch();
  const [poDoc, setPoDoc] = useState("");
  const [notFoundPoDoc, setNotFoundPoDoc] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();



  const handleSearch = () => {
    if (!poDoc.trim()) {
      // alert("Please enter a valid ECCI Number");
      dispatch(setAlert({ msg: "Please enter a valid ECCI Number", alertType: "warning" }));
      return;
    }
    axios
      .get(`/v1/api/po/status?poDoc=${poDoc}`)
      .then((response) => {
        console.log(response.data);

        if (response.data.results <= 0) {
          setNotFoundPoDoc(true);
        } else {
          navigate(`/trackingStatus/${poDoc}`);
        }
      })
      .catch((error) => {
        console.error("Something went wrong!", error);
        setNotFoundPoDoc(true);
      })
      .finally(() => {
        setLoading(false);
      });
  };




  return (
    <div className="track-main">
      <HeaderNavbar />
      <div className="container">
        <div className="container-gif">
          <img src={truckgif} alt="logo" className="truckgif" />
        </div>
        <div className="search-container">
          <div className="search-container-top">
            <TextField
              variant="outlined"
              placeholder="Enter PO Number to track..."
              value={poDoc}
              onChange={(e) => setPoDoc(e.target.value.trim())}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <SearchIcon
                      className="search-icon"
                      onClick={handleSearch}
                    />
                  </InputAdornment>
                ),
                style: {
                  borderRadius: "50px",
                  paddingRight: "8px",
                  paddingLeft: "20px",
                  background: "white",
                  height: "45px",
                  fontSize: "15px"
                },
              }}
              fullWidth
              onKeyPress={(e) => {
                if (e.key === "Enter") {
                  handleSearch();
                }
              }}
            />
            <FontAwesomeIcon
              icon={faSitemap}
              onClick={() => {
                if (!poDoc.trim()) {
                  dispatch(setAlert({ msg: "Please enter a valid ECCI Number", alertType: "warning" }));
                  return;
                }
                navigate("/POdetails", { state: { poDoc } });
              }}
              style={{
                marginLeft: "10px",
                color: "#003c78",
                fontSize: "25px",
                cursor: "pointer",
              }}
            />

          </div>
          <p style={{ fontSize: "11px", color: "#363636", marginTop: "10px" }}>
            Enter the PO number & press Enter.
          </p>
        </div>

        {loading && (
          <div className="text-center">
            <p style={{ color: "#363636" }}>Loading..</p>
          </div>
        )}

        {notFoundPoDoc && !loading && (
          <div className="text-center">
            <p style={{ color: "#363636", fontSize: "12px" }}>
              <i className="fa fa-frown-o text-black"> 😖 Something went wrong...try again after sometime.</i>
            </p>
          </div>
        )}
      </div>

      <div className="footer">
        <p style={{ fontSize: "12px", color: "grey" }}>
          &copy; {new Date().getFullYear()}, Emirates Logistics  | Developed By{" "}
          <Link
            to="http://globuslabs.com"
            className="text-dark "
            target="_blank"
          >
            Globus Labs
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Tracking;
















