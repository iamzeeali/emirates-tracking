import React, { useEffect, useState } from "react";
import { Table, Container, Row, Col, Spinner } from "react-bootstrap"; // Import Spinner
import "bootstrap/dist/css/bootstrap.min.css";
import NavbarAdmin from "../../../component/NavbarAdmin";
import {
  faCalendarDays,
  faCalendarDay,
  faTruckFast,
  faXmark,
  faFilePen,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import DateComponent from "../../../component/DateComponent/DateComponent";

const DispatchSummaryTable = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const today = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState(today);

  // console.log(data, "data134");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`v1/api/ecci/dispatchTable?date=${selectedDate}`);
        const result = await response.json();
        setData(result);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [selectedDate]);

  const styles = {
    headerDay: { backgroundColor: "#dddddd", color: "#333333" },
    headerDate: { backgroundColor: "#b9c3e0", color: "#333333" },
    headerEcciDispatch: { backgroundColor: "#2882a0", color: "white" },
    headerEcciDispatched: { backgroundColor: "#3f5a36", color: "white" },
    headerEcciNotDispatched: { backgroundColor: "#8c4748", color: "white" },
    cellEcciDispatch: { backgroundColor: "#b4d9e5", color: "#333333" },
    cellEcciCollected: { backgroundColor: "#d9ead3", color: "#333333" },
    cellEcciNotCollected: { backgroundColor: "#f4d4d5", color: "#333333" },
    remark: { backgroundColor: "pink", color: "#333333" },
  };

  if (error) return <div>Error: {error.message}</div>;

  return (
    <Container fluid className="p-0">
      <NavbarAdmin />
      <Row className="mt-4 mx-2" style={headerStyle}>
        <Col className="d-flex align-items-center justify-content-between">
          <h3 className="mb-0" style={headerTextStyle}>
            Dispatch Summary
          </h3>
          <div>
            <DateComponent selectedDate={selectedDate} setSelectedDate={setSelectedDate} />
          </div>
        </Col>
      </Row>
      <Container fluid className="mt-4" style={{ height: "calc(100vh - 200px)", overflow: "auto" }}>
        <Table bordered hover responsive>
          <thead className="sticky-top" style={{ verticalAlign: "middle" }}>
            {/* Top-level header row */}
            <tr>
              <th rowSpan="2" className="text-center" style={styles.headerDay}>
                Days
                <FontAwesomeIcon icon={faCalendarDay} style={{ marginLeft: "5px" }} />
              </th>
              <th rowSpan="2" className="text-center" style={styles.headerDate}>
                Date
                <FontAwesomeIcon icon={faCalendarDays} style={{ marginLeft: "5px" }} />
              </th>
              <th colSpan="3" className="text-center" style={styles.headerEcciDispatch}>
                ECCI for Dispatch
                <FontAwesomeIcon icon={faTruckFast} style={{ marginLeft: "5px" }} />
              </th>
              <th colSpan="6" className="text-center" style={styles.headerEcciDispatched}>
                ECCI Dispatched
                <FontAwesomeIcon icon={faXmark} style={{ marginLeft: "5px" }} />
              </th>
              <th colSpan="3" className="text-center" style={styles.headerEcciNotDispatched}>
                ECCI not Dispatched
                <FontAwesomeIcon icon={faXmark} style={{ marginLeft: "5px" }} />
              </th>
              <th rowSpan="2" style={styles.remark} className="text-center">
                Remarks
                <FontAwesomeIcon icon={faFilePen} style={{ marginLeft: "5px" }} />
              </th>
            </tr>
            {/* Sub-header row */}
            <tr>
              <th style={styles.cellEcciDispatch} className="text-center">
                No.of ECCI for Dispatch (Current Date)-A
              </th>
              <th style={styles.cellEcciDispatch} className="text-center">No.of ECCI for Dispatch (Backlog)</th>
              <th style={styles.cellEcciDispatch} className="text-center">
                Total No. of ECCI for Dispatch (Current + Backlog)
              </th>
              <th style={styles.cellEcciCollected} className="text-center">
                No. of ECCI Dispatched (Current Date)
              </th>
              <th style={styles.cellEcciCollected} className="text-center">
                No. of ECCI Dispatched (Backlog)
              </th>
              <th style={styles.cellEcciCollected} className="text-center">
                Total No. of ECCI Dispatched (Current + Backlog)
              </th>
              <th style={styles.cellEcciCollected} className="text-center">
                No. ECCI Dispatched &lt;24 hrs
              </th>
              <th style={styles.cellEcciCollected} className="text-center">
                No. ECCI Dispatched &gt;24 hrs
              </th>
              <th style={styles.cellEcciCollected} className="text-center">
                % of ECCI Dispatched Same Day
              </th>
              <th style={styles.cellEcciNotCollected} className="text-center">Total No. of ECCI</th>
              <th style={styles.cellEcciNotCollected} className="text-center">Previous Days ECCI</th>
              <th style={styles.cellEcciNotCollected} className="text-center">Current Day ECCI</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="15" className="text-center">
                  <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </Spinner>
                </td>
              </tr>
            ) : (
              data.reverse().map((row, index) => (
                <tr key={index}>
                  <td> {row.day}</td>
                  <td style={{ backgroundColor: '#f0f8ff', fontWeight: 'bold', border: '1px solid #ddd', whiteSpace: 'nowrap', minWidth: '120px' }}>{row.date}</td>
                  <td>{row.Number_Of_ECCI_for_dispatch}</td>
                  <td>{row.Number_Of_Backlog_ECCI}</td>
                  <td>{row.Total_Number_Of_ECCI_for_dispatch}</td>
                  <td>{row.No_Of_ECCI_Dispatched_On_Same_Day}</td>
                  <td>{row.No_Of_backlog_ECCI_for_Dispatched}</td>
                  <td>{row.Total_No_Of_ECCI_Dispatched_With_Backlog}</td>
                  <td>{row.No_ECCI_Dispatched_Within_24_hrs}</td>
                  <td>{row.No_ECCI_Dispatched_After_24_hrs}</td>
                  <td>{(row.Percentage_OF_ECCI_dispatch_On_Same_Day ?? 0).toFixed(2)}%</td>
                  <td>{row.Total_No_Of_Not_Dispatched_ECCI}</td>
                  <td>{row.Not_Dispatched_ECCI_Of_Previous_Date}</td>
                  <td>{row.Not_Dispatched_ECCI_Of_Current_Date}</td>
                  <td>{row.remarks || ""}</td>
                </tr>
              ))
            )}
          </tbody>
        </Table>
      </Container>
    </Container>
  );
};

export default DispatchSummaryTable;

// Styles
const headerStyle = {
  height: "60px",
  backgroundColor: "#e9ecef",
  borderBottom: "2px solid #ced4da",
  padding: "10px",
};

const headerTextStyle = {
  fontSize: "17px",
  textTransform: "uppercase",
  fontWeight: "600",
  color: "#333",
};
