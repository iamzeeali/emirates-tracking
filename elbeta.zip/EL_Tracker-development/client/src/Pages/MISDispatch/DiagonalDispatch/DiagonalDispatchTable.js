import React from 'react';
import { Col, Container, Row, Table } from 'react-bootstrap';
import NavbarAdmin from "../../../component/NavbarAdmin";

const DiagonalDispatchTable= () => {
  const headers = [
    'Date', 'Days', 'No. of ECCI dispatch',
    '1-Sep', '2-Sep', '3-Sep', '4-Sep', '5-Sep', '6-Sep', '7-Sep', '8-Sep', 
    '9-Sep', '10-Sep', '11-Sep', '12-Sep', '13-Sep', '14-Sep', '15-Sep', 
    '16-Sep', '17-Sep', '18-Sep', '19-Sep', '20-Sep', '21-Sep', '22-Sep', 
    '23-Sep', '24-Sep', '25-Sep', '26-Sep', '27-Sep', '28-Sep', '29-Sep', 
    '30-Sep', 'Total', 'Balance'
  ];

  const rows = [
    { date: '1-Sep-24', day: 'Sunday', collection: 0, daily: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], total: 0, balance: 0 },
    { date: '2-Sep-24', day: 'Monday', collection: 88, daily: [88, 92, 74, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], total: 254, balance: 166 },
    { date: '3-Sep-24', day: 'Tuesday', collection: 120, daily: [110, 0, 100, 105, 120, 115, 110, 115, 110, 115, 120, 115, 110, 105, 100, 95, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25], total: 2355, balance: 700 },
    { date: '4-Sep-24', day: 'Wednesday', collection: 95, daily: [95, 0, 92, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68], total: 1834, balance: 800 },
    { date: '5-Sep-24', day: 'Thursday', collection: 105, daily: [105, 0, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128], total: 2634, balance: 900 },
    { date: '6-Sep-24', day: 'Friday', collection: 130, daily: [130, 0, 129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102], total: 3084, balance: 1100 },
    { date: '7-Sep-24', day: 'Saturday', collection: 75, daily: [75, 0, 76, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48], total: 1503, balance: 500 },
    { date: '8-Sep-24', day: 'Sunday', collection: 0, daily: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], total: 0, balance: 0 },
  ];

  // Calculate totals for each relevant column
  const totals = {
    collection: 0,
    daily: Array(30).fill(0), // Adjust the size according to the number of days shown
    total: 0,
    balance: 0
  };

  rows.forEach(row => {
    totals.collection += row.collection;
    row.daily.forEach((value, index) => {
      totals.daily[index] += value;
    });
    totals.total += row.total;
    totals.balance += row.balance;
  });

  return (
    <Container fluid className="p-0">
    <NavbarAdmin />
    <Row className="mt-4 mx-2" style={headerStyle}>
      <Col className="d-flex align-items-center">
        <h3 className="mb-0" style={headerTextStyle}>
        Diagonal Dispatch
        </h3>
      </Col>
    </Row>
    <Container fluid className="mt-2">
    <Table bordered hover responsive size="sm" style={{ width: '100%', fontSize: '12px', textAlign: 'center', margin: '20px 0', borderCollapse: 'collapse' }}>
      <thead>
        <tr>
          {headers.map((header, index) => (
            <th key={index} style={{ backgroundColor: '#e9ecef', fontWeight: 'bold', padding: '8px', border: '1px solid #ddd', minWidth: index === 0 ? '120px' : '80px' }}>
              {header}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, rowIndex) => (
          <tr key={rowIndex}>
            <td style={{ backgroundColor: '#f0f8ff', fontWeight: 'bold', padding: '8px', border: '1px solid #ddd', whiteSpace: 'nowrap', minWidth: '120px' }}>{row.date}</td>
            <td style={{ padding: '8px', border: '1px solid #ddd', minWidth: '80px' }}>{row.day}</td>
            <td style={{ padding: '8px', border: '1px solid #ddd', minWidth: '150px' }}>{row.collection}</td>
            {row.daily.map((cell, cellIndex) => (
              <td key={cellIndex} style={{ padding: '8px', border: '1px solid #ddd', minWidth: '80px' }}>{cell !== 0 ? cell : ''}</td>
            ))}
            <td style={{ backgroundColor: '#f0f8ff', fontWeight: 'bold', padding: '8px', border: '1px solid #ddd', minWidth: '80px' }}>{row.total}</td>
            <td style={{ backgroundColor: '#f0f8ff', fontWeight: 'bold', padding: '8px', border: '1px solid #ddd', minWidth: '80px' }}>{row.balance}</td>
          </tr>
        ))}
        <tr style={{ backgroundColor: '#f5f5f5', fontWeight: 'bold' }}>
          <td colSpan={2} style={{background:"#2882a0", color:"white"}}>Total</td>
          <td style={{background:"#f0f8ff"}}>{totals.collection}</td>
          {totals.daily.map((total, index) => (
            <td key={index} style={{background:"#f0f8ff"}}>{total}</td>
          ))}
          <td style={{background:"#2882a0", color:"white"}}>{totals.total}</td>
          <td style={{background:"#2882a0", color:"white"}}>{totals.balance}</td>
        </tr>
      </tbody>
    </Table>
    </Container>
    </Container>
  );
};

export default DiagonalDispatchTable

// Styles
const headerStyle = {
    height: "60px",
    backgroundColor: "#e9ecef",
    borderBottom: "2px solid #ced4da",
    padding: "10px",
  };
  
  const headerTextStyle = {
    fontSize: "17px",
    textTransform: "uppercase",
    fontWeight: "600",
    color: "#333",
  };
  
