import React, { useState, useEffect } from 'react';
import { Col, Container, Row, Table } from 'react-bootstrap';
import NavbarAdmin from "../../../component/NavbarAdmin";
import DateComponent from '../../../component/DateComponent/DateComponent';
import axios from 'axios';

const DiagonalCollectionTable = () => {
  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });

  const [rows, setRows] = useState([]);
  const [headers, setHeaders] = useState([]);
  const [totals, setTotals] = useState({
    collection: 0,
    daily: [],
    total: 0,
    balance: 0,
  });

  // Function to generate headers based on the selected month
  const generateHeaders = (date) => {
    const selectedMonth = new Date(date);
    const monthName = selectedMonth.toLocaleString('en-US', { month: 'long' });
    const year = selectedMonth.getFullYear();
    const daysInMonth = new Date(year, selectedMonth.getMonth() + 1, 0).getDate();

    const dateHeaders = Array.from({ length: daysInMonth }, (_, i) => `${i + 1}-${monthName.substring(0, 3)}`);
    return ['Date', 'Days', 'No. of ECCI Collection', ...dateHeaders, 'Total', 'Balance'];
  };

  const fetchData = async (date) => {
    try {
      const response = await axios.get(`http://localhost:1433/v1/api/ecci/diagonalChart?date=${date}`);
      const data = response.data;

      // Transform data for the table
      const selectedMonth = new Date(date).getMonth();
      const daysInMonth = new Date(new Date(date).getFullYear(), selectedMonth + 1, 0).getDate();
      const formattedRows = data.map((item) => {
        const dailyData = Array(daysInMonth).fill(0);
        Object.entries(item.collectionDetails || {}).forEach(([key, value]) => {
          const collectionDate = new Date(key);
          if (collectionDate.getMonth() === selectedMonth) {
            const day = collectionDate.getDate();
            dailyData[day - 1] = value.collectionCount;
          }
        });

        return {
          date: item.date,
          day: new Date(item.date).toLocaleString('en-US', { weekday: 'long' }),
          collection: item.collectionCount || 0,
          daily: dailyData,
          total: item.EcciCount || 0,
          balance: item.balance || 0,
        };
      });

      // Calculate totals
      const totalsData = {
        collection: 0,
        daily: Array(daysInMonth).fill(0),
        total: 0,
        balance: 0,
      };

      formattedRows.forEach((row) => {
        totalsData.collection += row.collection;
        row.daily.forEach((value, index) => {
          totalsData.daily[index] += value;
        });
        totalsData.total += row.total;
        totalsData.balance += row.balance;
      });

      setRows(formattedRows);
      setTotals(totalsData);
      setHeaders(generateHeaders(date));
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    fetchData(selectedDate);
  }, [selectedDate]);

  useEffect(() => {
    setHeaders(generateHeaders(selectedDate));
  }, [selectedDate]);

  return (
    <Container fluid className="p-0">
      <NavbarAdmin />
      <Row className="mt-4 mx-2" style={headerStyle}>
        <Col className="d-flex align-items-center justify-content-between">
          <h3 className="mb-0" style={headerTextStyle}>
            Diagonal Collection
          </h3>
          <div>
            <DateComponent selectedDate={selectedDate} setSelectedDate={setSelectedDate} />
          </div>
        </Col>
      </Row>
      <Container fluid className="mt-2" style={{height: "calc(100vh - 200px)", overflow: "auto"}}>
        <Table bordered hover responsive size="sm" style={{ width: '100%', fontSize: '12px', textAlign: 'center', margin: '20px 0', borderCollapse: 'collapse' }}>
          <thead  style={{verticalAlign:"middle"}}>
            <tr>
              {headers.map((header, index) => (
                <th key={index} style={{ backgroundColor: '#e9ecef', fontWeight: 'bold', padding: '8px', border: '1px solid #ddd', minWidth: index === 0 ? '120px' : '80px' }}>
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, rowIndex) => (
              <tr key={rowIndex}>
                <td style={{ backgroundColor: '#f0f8ff', fontWeight: 'bold', padding: '8px', border: '1px solid #ddd', whiteSpace: 'nowrap', minWidth: '120px' }}>{row.date}</td>
                <td style={{ padding: '8px', border: '1px solid #ddd', minWidth: '80px' }}>{row.day}</td>
                <td style={{ padding: '8px', border: '1px solid #ddd', minWidth: '150px' }}>{row.collection}</td>
                {row.daily.map((cell, cellIndex) => (
                  <td key={cellIndex} style={{ padding: '8px', border: '1px solid #ddd', minWidth: '80px' }}>{cell !== 0 ? cell : ''}</td>
                ))}
                <td style={{ backgroundColor: '#f0f8ff', fontWeight: 'bold', padding: '8px', border: '1px solid #ddd', minWidth: '80px' }}>{row.total}</td>
                <td style={{ backgroundColor: '#f0f8ff', fontWeight: 'bold', padding: '8px', border: '1px solid #ddd', minWidth: '80px' }}>{row.balance}</td>
              </tr>
            ))}
            <tr style={{ backgroundColor: '#f5f5f5', fontWeight: 'bold' }}>
              <td colSpan={2} style={{ background: "#2882a0", color: "white" }}>Total</td>
              <td style={{ background: "#f0f8ff" }}>{totals.collection}</td>
              {totals.daily.map((total, index) => (
                <td key={index} style={{ background: "#f0f8ff" }}>{total}</td>
              ))}
              <td style={{ background: "#2882a0", color: "white" }}>{totals.total}</td>
              <td style={{ background: "#2882a0", color: "white" }}>{totals.balance}</td>
            </tr>
          </tbody>
        </Table>
      </Container>
    </Container>
  );
};

export default DiagonalCollectionTable;

// Styles
const headerStyle = {
  height: "60px",
  backgroundColor: "#e9ecef",
  borderBottom: "2px solid #ced4da",
  padding: "10px",
};

const headerTextStyle = {
  fontSize: "17px",
  textTransform: "uppercase",
  fontWeight: "600",
  color: "#333",
};
