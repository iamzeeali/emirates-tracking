import React, { useState, useEffect } from "react";
import { Table, Container, Row, Col, Spinner } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  faCalendarDays,
  faTruckFast,
  faXmark,
  faFilePen
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import NavbarAdmin from "../../../component/NavbarAdmin";
import DateComponent from "../../../component/DateComponent/DateComponent";

const CollectionSummaryTable = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const today = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState(today); 


  console.log(data, "data");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`v1/api/ecci/collectionTable?date=${selectedDate}`);
        const result = await response.json();
        setData(result);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [selectedDate]);

  const styles = {
    headerDate: { backgroundColor: "#2882a0", color: "white" },
    headerEcciCollected: { backgroundColor: "#3f5a36", color: "white" },
    headerEcciNotCollected: { backgroundColor: "#8c4748", color: "white" },
    cellDate: { backgroundColor: "#b4d9e5", color: "#333333" },
    cellEcciCollected: { backgroundColor: "#d9ead3", color: "#333333" },
    cellEcciNotCollected: { backgroundColor: "#f4d4d5", color: "#333333" },
    remark: { backgroundColor: "pink", color: "#333333" },
  };

  if (error) return <div>Error: {error.message}</div>;

  return (
    <Container fluid className="p-0">
      <NavbarAdmin />
      <Row className="mt-4 mx-2" style={headerStyle}>
        <Col className="d-flex align-items-center justify-content-between">
          <h3 className="mb-0" style={headerTextStyle}>
            Collection Summary
          </h3>
          <div>
            <DateComponent selectedDate={selectedDate} setSelectedDate={setSelectedDate} />
          </div>
        </Col>
      </Row>
      <Container fluid className="mt-4" style={{height: "calc(100vh - 200px)", overflow: "auto", }}>
        <Table bordered hover responsive  style={{background:"red"}} >
          <thead className="sticky-top-0" style={{verticalAlign:"middle"}}>
            <tr>
              <th colSpan="4" className="text-center" style={styles.headerDate}>
                Date
                <FontAwesomeIcon icon={faCalendarDays} style={{ marginLeft: "5px" }} />
              </th>
              <th colSpan="6" className="text-center" style={styles.headerEcciCollected}>
                ECCI Collected
                <FontAwesomeIcon icon={faTruckFast} style={{ marginLeft: "5px" }} />
              </th>
              <th colSpan="4" className="text-center" style={styles.headerEcciNotCollected}>
                ECCI not Collected
                <FontAwesomeIcon icon={faXmark} style={{ marginLeft: "5px" }} />
              </th>
            </tr>
            <tr>
              <th style={styles.cellDate} className="text-center">Date</th>
              <th style={styles.cellDate} className="text-center">No. of ECCI for Collection (Current Date)</th>
              <th style={styles.cellDate} className="text-center">No. of ECCI for Collection (Backlog)</th>
              <th style={styles.cellDate} className="text-center">Total No. of ECCI for Collection (Current + Backlog)</th>
              <th style={styles.cellDate} className="text-center">No. of ECCI Collected (Current Date)</th>
              <th style={styles.cellDate} className="text-center">No. of ECCI Collected (Backlog Date)</th>
              <th style={styles.cellDate} className="text-center">Total No. of ECCI Collected (Current + Backlog)</th>
              <th style={styles.cellEcciCollected} className="text-center">No. ECCI Collected &lt;24 hrs</th>
              <th style={styles.cellEcciCollected} className="text-center">No. ECCI Collected &gt;24 hrs</th>
              <th style={styles.cellEcciCollected} className="text-center">% of ECCI Collection Same Day</th>
              <th style={styles.cellEcciNotCollected} className="text-center">Total No. of ECCI</th>
              <th style={styles.cellEcciNotCollected} className="text-center">Previous Days ECCI</th>
              <th style={styles.cellEcciNotCollected} className="text-center">Current Day ECCI</th>
              <th style={styles.cellEcciNotCollected} className="text-center">Remark</th>
            </tr>
          </thead>
          <tbody>
          {loading ? (
              <tr>
                <td colSpan="15" className="text-center">
                  <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </Spinner>
                </td>
              </tr>
            ) : (
            data.reverse().map((row, index) => (
              <tr key={index}>
                <td style={{ backgroundColor: '#f0f8ff', fontWeight: 'bold', border: '1px solid #ddd', whiteSpace: 'nowrap', minWidth: '120px' }}>
                  {row.date}
                </td>
                <td>{row.Number_Of_ECCI_for_Collection}</td>
                <td>{row.Number_Of_Backlog_ECCI}</td>
                <td>{row.Total_Number_Of_ECCI_for_Collection}</td>
                <td>{row.No_Of_ECCI_Collected_On_Same_Day}</td>
                <td>{row.No_Of_Backlog_ECCI_Collected_On_This_Day}</td>
                <td>{row.Total_No_Of_ECCI_Collected_With_Backlog}</td>
                <td>{row.No_Of_ECCI_Collected_Within_24_hrs}</td>
                <td>{row.No_Of_ECCI_Collected_After_24_hrs}</td>
                <td>{(row.Percentage_OF_ECCI_Collection_On_Same_Day ?? 0).toFixed(2)}%</td>
                <td>{row.Total_No_Of_Not_Collected_ECCI}</td>
                <td>{row.Not_Collected_ECCI_Of_Previous_Date}</td>
                <td>{row.Not_Collected_ECCI_Of_Current_Date}</td>
                <td>{row.Remarks || ""}</td>
              </tr>
            ))
          )}
          </tbody>
        </Table>
      </Container>
    </Container>
  );
};

export default CollectionSummaryTable;

// Styles
const headerStyle = {
  height: "60px",
  backgroundColor: "#e9ecef",
  borderBottom: "2px solid #ced4da",
  padding: "10px",
};

const headerTextStyle = {
  fontSize: "17px",
  textTransform: "uppercase",
  fontWeight: "600",
  color: "#333",
};
