import React, { useEffect, useState } from "react";
import { Container, Row, Col, Button, Form, Modal } from "react-bootstrap";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { grnUpload, latestUploadedByGrn } from "../../../features/grnSlice";
import { setAlert } from "../../../features/alertSlice";
import axios from "axios";
import moment from "moment";
import Spinner from 'react-bootstrap/Spinner';


const Grn = () => {
  const dispatch = useDispatch();
  const [show, setShow] = useState(false);
  const [grnfile, setGrnfile] = useState(null);
  const [manualData, setManualData] = useState({
    poDoc: "",
    vendorCode: "",
    itemCode: "",
    transactionType: "",
    modeOfDelivery: "",
    inDate: "",
    transDate: "",
    invoiceNumber: "",
    invoiceValue: "",
    invoiceDate: "",
    deliveryPlant:"",
    uploadedBy: "",
  });



  console.log(manualData);
  

  const { latestUploadByGrnData } = useSelector((state) => state.grnUpload);

  const [loading, setLoading] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setGrnfile(file);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setManualData({
      ...manualData,
      [name]: value,
    });
  };



  useEffect(() => {
    dispatch(latestUploadedByGrn())
  }, [dispatch])

  // Excel data file upload

  const handleFileUpload = async (e) => {
    e.preventDefault();

    if (!grnfile) {
      dispatch(
        setAlert({
          msg: "Please select a file to upload.",
          alertType: "warning",
        })
      );
      return;
    }

    if (grnfile.name !== "grn_rep22248.xlsx") {
      dispatch(
        setAlert({
          msg: "Invalid file. Please upload the correct ASN report.",
          alertType: "warning",
        })
      );
      return;
    }

    const formData = new FormData();
    formData.append("file", grnfile);
    formData.append("uploadedBy", "mitesh");

    setLoading(true);

    try {
      await dispatch(grnUpload(formData)).unwrap();
      await dispatch(latestUploadedByGrn())

      setGrnfile(null);
    } catch (err) {
      console.log(err, "Something went wrong");
    } finally {
      setLoading(false);
    }
  };
  //manual ecci form submit data

  const handleManualSubmit = async () => {
    try {
      const response = await axios.post("/v1/api/grn/", {
        ...manualData,
        uploadedBy: "mitesh",
      });
      console.log("Response from server:", response.data);
      await dispatch(latestUploadedByGrn())

      dispatch(
        setAlert({
          msg: "Manual ASN data submitted successfully!",
          alertType: "success",
        })
      );
      setManualData({
        poDoc: "",
    vendorCode: "",
    itemCode: "",
    transactionType: "",
    modeOfDelivery: "",
    inDate: "",
    transDate: "",
    invoiceNumber: "",
    invoiceValue: "",
    invoiceDate: "",
    deliveryPlant:"",
    uploadedBy: "",
      });
      handleClose();
    } catch (error) {
      console.error("Error submitting manual ASN data:", error);
      dispatch(
        setAlert({
          msg: "Failed to submit the manual ASN data.",
          alertType: "error",
        })
      );
    }
  };


  return (
    <Container
      style={{
        width: "100%",
        height: "100%",
        background: "white",
      }}
      className="p-0"
    >
      <div className="text-center mb-3">
        <h4 style={{ margin: "10px 0px", fontSize: "17px" }}>
          GRN REPORT - TO BE RECEIVED (REP222458)
        </h4>
      </div>
      <div className="text-center mb-3">
        <Link to="/GrnTable">
          <Button variant="primary" style={{ ...buttonStyle }}>
            View Report
          </Button>
        </Link>
      </div>
      <Form onSubmit={handleFileUpload}>
        <Form.Group controlId="formFile" className="mb-3">
          <Form.Label style={labelStyle}>Upload GRN file</Form.Label>
          <Form.Control
            type="file"
            onChange={handleFileChange}
            style={inputStyle}
          />
        </Form.Group>

        {/* Display the Last Uploaded Information */}
        {latestUploadByGrnData ? (
          <p style={{ fontSize: "14px", color: "orange", textAlign: "center" }}>
            Last uploaded at: {moment(latestUploadByGrnData.uploadedAt).format("DD-MMM-YYYY, HH:mm")} by {latestUploadByGrnData.uploadedBy}
          </p>
        ) : (
          <p style={{ fontSize: "14px", color: "grey", textAlign: "center" }}>
            No GRN data available.
          </p>
        )}

        <Button
          variant={loading ? "secondary" : "primary"}
          type="submit"
          className="w-100"
          style={buttonStyle}
          disabled={loading}
        >
          {loading ? (
            <>
              <Spinner as="span" animation="grow" size="sm" role="status" aria-hidden="true" />
              Uploading...
            </>
          ) : (
            "UPLOAD"
          )}
        </Button>

        <p className="text-center mt-3">OR</p>

        <Button
          variant="primary"
          className="w-100 mb-4"
          style={{ ...buttonStyle }}
          onClick={handleShow}
        >
          ADD MANUALLY
        </Button>
      </Form>

      <Modal show={show} onHide={handleClose} centered size="lg">
        <Modal.Header closeButton style={{ borderBottom: "2px solid #003c78" }}>
          <Modal.Title
            style={{ fontWeight: "bold", fontSize: "18px", color: "#003c78" }}
          >
            ADD GRN REPORT MANUALLY
          </Modal.Title>
        </Modal.Header>
        <Modal.Body style={modalBodyStyle}>
          <Form>
            <Row className="align-items-center">
              {inputFields.map((field) => (
                <Col xs={6} md={6} key={field.controlId}>
                  <Form.Group controlId={field.controlId} className="mb-2">
                    <Form.Label style={labelStyle}>{field.label}</Form.Label>
                    <Form.Control
                      type={field.type}
                      name={field.name}
                      placeholder={field.placeholder}
                      style={inputStyle}
                      value={manualData[field.name]}
                      onChange={handleInputChange}
                    />
                  </Form.Group>
                </Col>
              ))}
            </Row>
          </Form>
        </Modal.Body>

        <Modal.Footer style={{ borderTop: "none", paddingTop: "0px" }}>
          <Button variant="secondary" onClick={handleClose} style={buttonStyle}>
            Close
          </Button>
          <Button
            variant="primary"
            onClick={handleManualSubmit}
            style={buttonStyle}
          >
            Submit
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

const modalBodyStyle = {
  padding: "20px",
};

const labelStyle = { fontWeight: "bold", fontSize: "14px", margin: "3px" };
const inputStyle = { borderRadius: "8px", fontSize: "14px" };
const buttonStyle = {
  background: "#f90",
  borderRadius: "8px",
  fontSize: "13px",
  border: "transparent",
};

const inputFields = [
  {
    name: "poDoc",
    label: "Po Doc",
    placeholder: "Enter PO Number",
    controlId: "po-Doc",
    type: "text",
  },
  {
    name: "vendorCode",
    label: "Vendor Code",
    placeholder: "Enter vendor Code",
    controlId: "vendor-code",
    type: "text",
  },
  {
    name: "itemCode",
    label: "Item Code",
    placeholder: "Enter item Code",
    controlId: "item-code",
    type: "text",
  },
  {
    name: "transactionType",
    label: "Transaction Type",
    placeholder: "Enter Transaction Type",
    controlId: "transactionType",
    type: "text",
  },
  {
    name: "modeOfDelivery",
    label: "Mode Of Delivery",
    placeholder: "Enter Mode Of Delivery",
    controlId: "modeOfDelivery",
    type: "text",
  },
  {
    name: "inDate",
    label: "In Date",
    controlId: "in-Date",
    type: "date",
  },
  {
    name: "transDate",
    label: "Trans Date",
    controlId: "transDateLT",
    type: "date",
  },
  {
    name: "invoiceNumber",
    label: "Invoice Number",
    placeholder: "Enter invoice Number",
    controlId: "invoice-Number",
    type: "text",
  },
  {
    name: "invoiceValue",
    label: "Invoice Value",
    placeholder: "Enter invoice Value",
    controlId: "invoice-Value",
    type: "text",
  },
  {
    name: "invoiceDate",
    label: "Invoice Date",
    controlId: "invoice-Date",
    type: "date",
  },
  {
    name: "deliveryPlant",
    label: "Delivery Plant",
    placeholder: "Enter delivery Plant",
    controlId: "delivery-Plant",
    type: "text",
  },

];

export default Grn;
