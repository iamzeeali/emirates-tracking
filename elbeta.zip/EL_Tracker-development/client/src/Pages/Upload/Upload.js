// import React from "react";
// import Asns from "./Asns/Asns";
// import Grn from "./Grn/Grn";

// import "./Upload.css";
// import { Col, Row } from "react-bootstrap";
// import NavbarAdmin from "../../component/NavbarAdmin";


// const Upload = () => {
//   return (
//     <div className="upload-main">

//       <NavbarAdmin/>
    

//       {/* Header Section */}
//       <Row
//         className="mt-4 mx-2"
//         style={{ height: "60px", background: "#f3f3f3" }}
//       >
//         <Col className="d-flex align-items-center">
//           <h3
//             className="mb-0"
//             style={{
//               fontSize: "17px",
//               textTransform: "uppercase",
//               fontWeight: "600",
//             }}
//           >
//             Upload or Create ASN & GRN Report
//           </h3>
//         </Col>
//       </Row>

//       {/* Content Section */}
//       <Row
//         className="flex-grow-1 d-flex align-items-center justify-content-center m-2"
//         style={{ background: "#f3f3f3" }}
//       >
//         <Col md={6} className="p-2 d-flex justify-content-center">
//           <Asns />
//         </Col>
//         <Col md={6} className="p-2 d-flex justify-content-center">
//           <Grn />
//         </Col>
//       </Row>
//     </div>
//   );
// };

// export default Upload;



import React from "react";
import Asns from "./Asns/Asns";
import Grn from "./Grn/Grn";
import "./Upload.css";
import { Col, Row, Container } from "react-bootstrap";
import NavbarAdmin from "../../component/NavbarAdmin";
import gif from '../../assets/giphy.gif'

const Upload = () => {



  
  return (
    <div className="upload-main" style={{ backgroundColor: "#f9f9f9", minHeight: "100vh" }}>
      <NavbarAdmin />

      {/* Header Section */}
      <Row className="mt-4 mx-2" style={headerStyle}>
        <Col className="d-flex align-items-center justify-content-between">
          <h3 className="mb-0" style={headerTextStyle}>
            Upload or Create ASN & GRN Report
          </h3>
         <img src={gif} style={{height:"40px"}}/>
        </Col>
      </Row>

      {/* Content Section */}
      <Container fluid className="py-4">
        <Row className="flex-grow-1 d-flex align-items-center justify-content-evenly">
          <Col md={5} className="p-3 d-flex justify-content-center" >
            <div style={cardStyle}>
              <Asns />
            </div>
          </Col>
          <Col md={5} className="p-3 d-flex justify-content-center">
            <div style={cardStyle}>
              <Grn />
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Upload;

// Styles
const headerStyle = {
  height: "55px",
  backgroundColor: "#e9ecef",
  borderBottom: "2px solid #ced4da",
  padding: "5px",
};

const headerTextStyle = {
  fontSize: "15px",
  textTransform: "uppercase",
  fontWeight: "600",
  color: "#003c78",
};

const cardStyle = {
  // background: "yellow",
  background: "#fff",
  padding: "20px",
  borderRadius: "8px",
  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
  width: "100%",
  height:"100%",
};
