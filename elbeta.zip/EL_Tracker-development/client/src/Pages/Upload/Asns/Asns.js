import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Modal, Button, Form, Row, Col, Container } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { asnUpload, latestUploadedByAsn } from "../../../features/asnSlice";
import { setAlert } from "../../../features/alertSlice";
import axios from "axios";
import moment from "moment";
import Spinner from "react-bootstrap/Spinner";

const Asns = () => {
  const dispatch = useDispatch();
  const [show, setShow] = useState(false);
  const [asnfile, setAsnfile] = useState(null);
  const [manualData, setManualData] = useState({
    poDoc: "",
    docDate: "",
    asnUploadDate: "",
    material: "",
    vendorCode: "",
    packageType: "",
    deliveryPlant: "",
    uploadedBy: "",
  });
  const { latestUploadByAsnData } = useSelector((state) => state.asnUpload);
  const [loading, setLoading] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setAsnfile(file);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setManualData({
      ...manualData,
      [name]: value,
    });
  };

  useEffect(() => {
    dispatch(latestUploadedByAsn());
  }, [dispatch]);

  // Excel data file upload
  const handleFileUpload = async (e) => {
    e.preventDefault();

    if (!asnfile) {
      dispatch(
        setAlert({
          msg: "Please select a file to upload.",
          alertType: "warning",
        })
      );
      return;
    }
    if (asnfile.name !== "asn_rep22246.xlsx") {
      dispatch(
        setAlert({
          msg: "Invalid file. Please upload the correct ASN report.",
          alertType: "warning",
        })
      );
      return;
    }
    const formData = new FormData();
    formData.append("file", asnfile);
    formData.append("uploadedBy", "mitesh");
    setLoading(true);

    try {
      await dispatch(asnUpload(formData)).unwrap();
      await dispatch(latestUploadedByAsn());
      setAsnfile(null);
    } catch (err) {
      console.error("File upload error:", err);
    } finally {
      setLoading(false);
    }
  };

  //manual ecci form submit data
  const handleManualSubmit = async () => {
    console.log("Manual ASN Data:", manualData);
    try {
      const response = await axios.post("/v1/api/asn/", {
        ...manualData,
        uploadedBy: "mitesh",
      });

      console.log("Response from server:", response.data);
      await dispatch(latestUploadedByAsn());

      dispatch(
        setAlert({
          msg: "Manual ASN data submitted successfully!",
          alertType: "success",
        })
      );
      setManualData({
        poDoc: "",
        docDate: "",
        asnUploadDate: "",
        material: "",
        vendorCode: "",
        packageType: "",
        deliveryPlant: "",
        uploadedBy: "",
      });
      handleClose();
    } catch (error) {
      console.error("Error submitting manual ASN data:", error);
      dispatch(
        setAlert({
          msg: "Failed to submit the manual ASN data.",
          alertType: "error",
        })
      );
    }
  };

  return (
    <Container
      style={{
        width: "100%",
        height: "100%",
      }}
      className="p-0"
    >
      <div className="text-center mb-3">
        <h4 style={{ margin: "10px 0px", fontSize: "17px" }}>
          ASN REPORT - TO BE RECEIVED (REP222456)
        </h4>
      </div>

      <div className="text-center mb-3">
        <Link to="/AsnsTable">
          <Button variant="primary" style={{ ...buttonStyle }}>
            View Report
          </Button>
        </Link>
      </div>

      <Form onSubmit={handleFileUpload}>
        <Form.Group controlId="formFile" className="mb-3">
          <Form.Label style={labelStyle}>Upload ASN file</Form.Label>
          <Form.Control
            type="file"
            onChange={handleFileChange}
            style={inputStyle}
          />
        </Form.Group>

        {/* Display the Last Uploaded Information */}
        {latestUploadByAsnData ? (
          <p style={{ fontSize: "14px", color: "orange", textAlign: "center" }}>
            Last uploaded at:{" "}
            {moment(latestUploadByAsnData.uploadedAt).format(
              "DD-MMM-YYYY, HH:mm"
            )}{" "}
            by {latestUploadByAsnData.uploadedBy}
          </p>
        ) : (
          <p style={{ fontSize: "14px", color: "grey", textAlign: "center" }}>
            No ASN data available.
          </p>
        )}

        <Button
          variant={loading ? "secondary" : "primary"}
          type="submit"
          className="w-100"
          style={buttonStyle}
          disabled={loading}
        >
          {loading ? (
            <>
              <Spinner
                as="span"
                animation="grow"
                size="sm"
                role="status"
                aria-hidden="true"
              />
              Uploading...
            </>
          ) : (
            "UPLOAD"
          )}
        </Button>

        <p className="text-center mt-3">OR</p>

        <Button
          variant="primary"
          className="w-100 mb-4"
          style={{ ...buttonStyle }}
          onClick={handleShow}
        >
          ADD MANUALLY
        </Button>
      </Form>

      {/* Modal for Adding ASN */}
      <Modal show={show} onHide={handleClose} centered size="lg">
        <Modal.Header closeButton style={{ borderBottom: "2px solid #003c78" }}>
          <Modal.Title
            style={{ fontWeight: "bold", fontSize: "18px", color: "#003c78" }}
          >
            ADD ASN REPORT MANUALLY
          </Modal.Title>
        </Modal.Header>
        <Modal.Body style={modalBodyStyle}>
          <Form>
            <Row className="align-items-center">
              {inputFields.map((field) => (
                <Col xs={12} md={6} key={field.name}>
                  <Form.Group controlId={field.controlId} className="mb-2">
                    <Form.Label style={labelStyle}>{field.label}</Form.Label>
                    <Form.Control
                      type={field.type}
                      name={field.name}
                      placeholder={field.placeholder}
                      style={inputStyle}
                      value={manualData[field.name]}
                      onChange={handleInputChange}
                    />
                  </Form.Group>
                </Col>
              ))}
            </Row>
          </Form>
        </Modal.Body>
        <Modal.Footer style={{ borderTop: "none", paddingTop: "0px" }}>
          <Button variant="secondary" onClick={handleClose} style={buttonStyle}>
            Close
          </Button>
          <Button
            variant="primary"
            onClick={handleManualSubmit}
            style={buttonStyle}
          >
            Submit
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

const modalBodyStyle = {
  padding: "20px",
};

const labelStyle = { fontWeight: "bold", fontSize: "14px", margin: "3px" };
const inputStyle = { borderRadius: "8px", fontSize: "14px" };
const buttonStyle = {
  background: "#f90",
  borderRadius: "8px",
  fontSize: "13px",
  border: "transparent",
};

const inputFields = [
  {
    name: "poDoc",
    label: "PO Number",
    placeholder: "Enter PO Number",
    controlId: "PO-number",
    type: "text",
  },
  {
    name: "docDate",
    label: "doc Date",
    placeholder: "Enter Date",
    controlId: "doc-date",
    type: "date",
  },
  {
    name: "asnUploadDate",
    label: "ASN Upload Date",
    placeholder: "Enter Date",
    controlId: "asn-upload-date",
    type: "date",
  },
  {
    name: "material",
    label: "material",
    placeholder: "Enter material",
    controlId: "material",
    type: "text",
  },
  {
    name: "vendorCode",
    label: "Vendor Code",
    placeholder: "Enter Vendor Code",
    controlId: "vendor-code",
    type: "text",
  },
  {
    name: "packageType",
    label: "package Type",
    placeholder: "Enter package Type",
    controlId: "package-Type",
    type: "text",
  },
  {
    name: "deliveryPlant",
    label: "delivery Plant ",
    placeholder: "Enter delivery Plant",
    controlId: "delivery-Plant",
    type: "text",
  },
];

export default Asns;
