import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableRow, Button, Paper, Typography, Box } from '@mui/material';

function VendorTable() {
  const data = [
    { name: 'Globus', eccis: ['1010991019', '1010991020'], qty: 2 },
    { name: 'Max Auto', eccis: ['1012210292', '1012210293', '1012210294'], qty: 3 },
    { name: 'Apex', eccis: ['1013120001', '1013120002'], qty: 2 },
  ];

  return (
    <Paper elevation={3} style={{ padding: '10px', borderRadius: '8px', backgroundColor: '#f9f9f9',height:"100%", maxHeight:"100%", overflowY:"auto"}}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Box>
          <Button variant="contained" color="primary" style={{ marginRight: '10px' }}>
            Vehicle
          </Button>
          <Button variant="contained" color="secondary" style={{ marginRight: '10px' }}>
            Order
          </Button>
          <Button variant="contained" style={{ backgroundColor: '#4caf50', color: '#fff' }}>
            Vendor
          </Button>
        </Box>
      </Box>
      <Table style={{ minWidth: '100%' }}>
        <TableHead>
          <TableRow>
            <TableCell style={{ fontWeight: 'bold', color: '#555' }}>Name</TableCell>
            <TableCell style={{ fontWeight: 'bold', color: '#555' }}>ECCI</TableCell>
            <TableCell style={{ fontWeight: 'bold', color: '#555' }}>Qty</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((row, index) => (
            <TableRow key={index} style={{ backgroundColor: index % 2 === 0 ? '#f1f1f1' : '#ffffff' }}>
              <TableCell>{row.name}</TableCell>
              <TableCell>{row.eccis.join(', ')}</TableCell>
              <TableCell>{row.qty}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Paper>
  );
}

export default VendorTable;
