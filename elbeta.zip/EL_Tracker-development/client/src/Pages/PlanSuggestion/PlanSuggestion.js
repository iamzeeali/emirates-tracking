import React from 'react';
import './PlanSuggestion.css';
import MapContainer from './MapContainer/MapContainer';
import VendorTable from './VendorTable/VendorTable';
import VehicleDetails from './VehicleDetails/VehicleDetails';
import ScheduleGrid from './ScheduleGrid/ScheduleGrid';

function PlanSuggestion() {
  return (
    <div className="dashboard">
      <div className="map-container">
        <MapContainer />
      </div>
      <div className="vendor-table">
        <VendorTable />
      </div>
      <div className="vehicle-details">
        <VehicleDetails/>
      </div>
      <div className="schedule-grid">
        <ScheduleGrid />
      </div>
    </div>
  );
}

export default PlanSuggestion