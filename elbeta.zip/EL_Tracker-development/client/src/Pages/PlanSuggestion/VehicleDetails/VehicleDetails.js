import { Paper } from '@mui/material';
import React from 'react';
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';

function VehicleDetails() {
  return (
    <Paper elevation={3} style={{ padding: '10px', borderRadius: '8px', backgroundColor: '#f9f9f9', maxHeight:"100%", overflowY:"auto", minHeight:"100%" }}>
   <Card style={{ width: '100%', marginBottom:"10px" }}>
      <ListGroup variant="flush">
        <ListGroup.Item style={{color:"orange", fontSize:"12px"}}>182799181919</ListGroup.Item>
        <ListGroup.Item style={{fontWeight:"600", fontSize:"13px"}}>JH 05 AA 0001</ListGroup.Item>
      </ListGroup>
    </Card>
    <Card style={{ width: '100%', marginBottom:"10px" }}>
      <ListGroup variant="flush">
        <ListGroup.Item style={{color:"orange", fontSize:"12px"}}>182799181929</ListGroup.Item>
        <ListGroup.Item style={{fontWeight:"600", fontSize:"13px"}}>JH 05 AA 0002</ListGroup.Item>
      </ListGroup>
    </Card>
    <Card style={{ width: '100%', marginBottom:"10px" }}>
      <ListGroup variant="flush">
        <ListGroup.Item style={{color:"orange", fontSize:"12px"}}>182799181939</ListGroup.Item>
        <ListGroup.Item style={{fontWeight:"600", fontSize:"13px"}}>JH 05 AA 0002</ListGroup.Item>
      </ListGroup>
    </Card>
    </Paper>
  );
}

export default VehicleDetails;
