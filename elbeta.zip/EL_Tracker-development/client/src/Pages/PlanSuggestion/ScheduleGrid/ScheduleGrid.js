import React from "react";
import {
  MDBBtn,
  MDBCol,
  MDBContainer,
  MDBRow,
  MDBTypography,
} from "mdb-react-ui-kit";
import { Button, Paper } from "@mui/material";

export default function ScheduleGrid() {
  return (
    <div style={{background:"white", borderRadius:"8px", height:"100%"}}>
      <MDBContainer fluid className="py-5">
        <MDBRow>
          <MDBCol lg="12">
            <div className="horizontal-timeline">
              <MDBTypography listInLine className="items">
                <li className="items-list">
                  <div className="px-4">
                    <div className="event-date badge bg-info">
                      2 June 6:00 AM
                    </div>
                    <div className="details-info">
                      <Button
                        variant="contained"
                        color="primary"
                        style={{ marginRight: "10px" }}
                      >
                        W-64%
                      </Button>
                      <Button
                        variant="contained"
                        style={{ backgroundColor: "#4caf50", color: "#fff" }}
                      >
                        1
                      </Button>
                    </div>
                  </div>
                </li>
                <li className="items-list">
                  <div className="px-4">
                    <div className="event-date badge bg-success">
                      2 June 9:00 AM
                    </div>
                    <div className="details-info">
                      <Button
                        variant="contained"
                        color="primary"
                        style={{ marginRight: "10px" }}
                      >
                        W-64%
                      </Button>
                      <Button
                        variant="contained"
                        style={{ backgroundColor: "#4caf50", color: "#fff" }}
                      >
                        2
                      </Button>
                    </div>
                  </div>
                </li>
                <li className="items-list">
                  <div className="px-4">
                    <div className="event-date badge bg-danger">
                      2 June 1:00 PM
                    </div>
                    <div className="details-info">
                      <Button
                        variant="contained"
                        color="primary"
                        style={{ marginRight: "10px" }}
                      >
                        W-64%
                      </Button>
                      <Button
                        variant="contained"
                        style={{ backgroundColor: "#4caf50", color: "#fff" }}
                      >
                        3
                      </Button>
                    </div>
                  </div>
                </li>
                <li className="items-list">
                  <div className="px-4">
                    <div className="event-date badge bg-warning">
                      2 June 4:00 AM
                    </div>
                    <div className="details-info">
                      <Button
                        variant="contained"
                        color="primary"
                        style={{ marginRight: "10px" }}
                      >
                        W-64%
                      </Button>
                      <Button
                        variant="contained"
                        style={{ backgroundColor: "#4caf50", color: "#fff" }}
                      >
                        4
                      </Button>
                    </div>
                  </div>
                </li>
              </MDBTypography>
            </div>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
      <div>
        <ul
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "space-around",
            padding: "5px",
            flexWrap: "wrap",
           listStyle:"none"
          }}
        >
          <li>
            <span style={{ fontWeight: "bold" }}>Order:</span> 18272618919
          </li>
          <li>
            <span style={{ fontWeight: "bold" }}>Capacity:</span> 800
          </li>
          <li>
            <span style={{ fontWeight: "bold" }}>Load:</span> 795
          </li>
          <li>
            <span style={{ fontWeight: "bold" }}>Utilization:</span> 96%
          </li>
        </ul>
      </div>
    </div>
  );
}
