// Loading.js
import React from 'react';
import './Loading.css'; // Optional: Add custom styles for the loading spinner.

const Loading = () => {
  return (
    <div className="loading-container">
      <div className="spinner"></div>
      <p>Loading, please wait...</p>
    </div>
  );
};

export default Loading;
