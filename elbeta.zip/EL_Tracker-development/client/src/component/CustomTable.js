// CustomTable.js
import React from "react";
import { Table, Pagination } from "react-bootstrap";
import { AiOutlineEdit, AiOutlineDelete } from "react-icons/ai";

const CustomTable = ({ columns, rows, page, rowsPerPage, onPageChange }) => {
  return (
    <div>
      <Table responsive bordered hover>
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column.id} style={{ minWidth: column.minWidth, fontWeight: "700", textAlign: "center" }}>
                {column.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
            console.log(row.ECCI);
            
            return (
              <tr key={row}>
                {columns.map((column) => {
                  const value = row[column.id];
                  return (
                    <td key={column.id} style={{ textAlign: "center" }}>
                      {column.id === "actions" ? (
                        <>
                          <AiOutlineEdit style={{ fontSize: "18px", cursor: "pointer", marginRight: 10, color: "blue" }} />
                          <AiOutlineDelete style={{ fontSize: "18px", cursor: "pointer", marginRight: 10, color: "red" }} />
                        </>
                      ) : (
                        value
                      )}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </Table>

      {/* Pagination */}
      <Pagination className="justify-content-end">
        <Pagination.Prev onClick={() => onPageChange(page - 1)} disabled={page === 0} />
        <Pagination.Next onClick={() => onPageChange(page + 1)} disabled={page >= Math.ceil(rows.length / rowsPerPage) - 1} />
      </Pagination>
    </div>
  );
};

export default CustomTable;





