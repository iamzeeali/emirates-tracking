// import React, { useState } from 'react';
// import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
// import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
// import { DatePicker } from "@mui/x-date-pickers/DatePicker";
// import TextField from '@mui/material/TextField';
// import dayjs from 'dayjs';
// import './DateComponent.css';

// const getPreviousMonthYear = () => {
//   const currentDate = new Date();
//   currentDate.setMonth(currentDate.getMonth() - 3);
//   return dayjs(currentDate);
// };

// const DateComponent = () => {
//   const [selectedDate, setSelectedDate] = useState(getPreviousMonthYear());

//   return (
//     <div>
//       <LocalizationProvider dateAdapter={AdapterDayjs}>
//         <DatePicker
//           className="small-date-picker"
//           slotProps={{ textField: { size: 'small' } }}
//           label="Date"
//           openTo="day" // Ensures you can select year, month, and day
//           views={["year", "month", "day"]} // View all three: year, month, day
//           value={selectedDate}
//           onChange={(newDate) => setSelectedDate(newDate)} // Update the selected date
//           renderInput={(params) => (
//             <TextField
//               {...params}
//               // You can customize the format of the date here
//               value={selectedDate ? selectedDate.format("YYYY-MM-DD") : ""}
//             />
//           )}
//         />
//       </LocalizationProvider>
//     </div>
//   );
// };

// export default DateComponent;


import React from 'react';
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import TextField from '@mui/material/TextField';
import dayjs from 'dayjs';
import './DateComponent.css'

const DateComponent = ({ selectedDate, setSelectedDate }) => {

  const handleDateChange = (newDate) => {
    setSelectedDate(newDate ? newDate.format('YYYY-MM-DD') : ''); // Update the selected date in parent component
  };

  return (
    <div>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
         slotProps={{ textField: { size: 'small' } }}
          label="Date"
          openTo="day"
          views={["year", "month", "day"]}
          value={dayjs(selectedDate)} // Pass the selected date here
          onChange={handleDateChange} // Update the date in parent when changed
          renderInput={(params) => <TextField {...params} size="small" />}
        />
      </LocalizationProvider>
    </div>
  );
};

export default DateComponent;
