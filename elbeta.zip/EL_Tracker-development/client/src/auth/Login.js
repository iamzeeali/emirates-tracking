// import React, { useState } from "react";
// import { Form, Button, Container, Row, Col } from "react-bootstrap";
// import HeaderNavbar from "../component/HeaderNavbar";
// import { Link, useNavigate } from "react-router-dom";
// import "./Login.css";
// import logo from "../assets/el_logo.png";
// import axios from "axios";

// const Login = () => {
//   const [userdata, setUserData] = useState({
//     email: "",
//     password: "",
//   });

//   console.log(userdata);

//   const [isHovered, setIsHovered] = useState(false);
//   const navigate = useNavigate(); // Hook to handle navigation
//   const [loading, setLoading] = useState(false);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setUserData((prevData) => ({
//       ...prevData,
//       [name]: value,
//     }));
//   };



//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!userdata.email || !userdata.password) {
//       alert('Both username and password are required.');
//       return;
//     }

//     setLoading(true); // Set loading to true when the request is being sent

//     try {
//       const res = await axios.post('/v1/api/user/login', userdata, {
//         withCredentials: true,
//       });

//       console.log(res.status === 200);

//       if (res.status === 200) {
//         sessionStorage.setItem('token', res.data.token);
//         navigate('/upload');
//       } else {
//         alert('Invalid credentials. Please try again.');
//       }
//     } catch (error) {
//       console.error("Login error:", error);
//       alert('Something went wrong. Please try again later.');
//     } finally {
//       setLoading(false); // Set loading to false after the request completes (success or failure)
//     }
//   };


//   return (
//     <div className="login-main">
//       <HeaderNavbar />
//       <Container
//         className="d-flex align-items-center justify-content-end flex-row"
//         style={{ width: "100%", height: "calc(100vh - 150px)" }}
//       >
//         <Row
//           className="w-100 py-4 px-2 m-2"
//           style={{
//             maxWidth: "400px",
//             backgroundColor: "rgba(0, 0, 0, 0.8)",
//             borderRadius: "8px",
//           }}
//         >
//           <Col>
//             <div className="text-center mb-4">
//               <img src={logo} alt="OWM Logo" style={{ width: "65px" }} />
//               <hr style={{ color: "white", margin: "10px 0px" }} />
//               <h3 style={{ color: "white" }}>Sign In</h3>
//             </div>
//             <Form onSubmit={handleSubmit} className="login-form p-2 rounded">
//               <Form.Group className="mb-3" controlId="formBasicEmail">
//                 <Form.Control
//                   type="email"
//                   placeholder="UserName"
//                   name="email"
//                   value={userdata.email}
//                   onChange={handleChange}
//                   className="transparent-input"
//                   aria-label="Enter your userName"
//                 />
//               </Form.Group>
//               <Form.Group className="mb-3" controlId="formBasicPassword">
//                 <Form.Control
//                   type="password"
//                   placeholder="Password"
//                   name="password"
//                   value={userdata.password}
//                   onChange={handleChange}
//                   className="transparent-input"
//                   aria-label="Enter your password"
//                 />
//               </Form.Group>

//               <Button
//                 variant="primary"
//                 type="submit"
//                 className="w-100"
//                 style={{
//                   backgroundColor: isHovered
//                     ? "rgba(255, 255, 255, 0.2)"
//                     : "rgba(255, 255, 255, 0.1)",
//                   border: "1px solid rgba(255, 255, 255, 0.3)",
//                   color: "white",
//                   transition: "background-color 0.3s ease",
//                 }}
//                 onMouseEnter={() => setIsHovered(true)}
//                 onMouseLeave={() => setIsHovered(false)}
//                 disabled={loading}
//               >
//                 {loading ? 'Logging in....' : 'Login'}

//               </Button>
//               <div className="text-center mt-3">
//                 <Link
//                   to="/forgetPassword"
//                   style={{
//                     color: "white",
//                     fontSize: "12px",
//                     cursor: "pointer",
//                     textDecoration: "none",
//                   }}
//                 >
//                   Forgot Password?
//                 </Link>
//               </div>
//             </Form>
//             <div className="footer text-center my-3">
//               <p style={{ fontSize: "12px", color: "white" }}>
//                 Powered by{" "}
//                 <Link
//                   to="http://globuslabs.com"
//                   style={{ color: "white", textDecoration: "none" }}
//                   target="_blank"
//                   rel="noopener noreferrer"
//                 >
//                   Globus Labs
//                 </Link>
//               </p>
//             </div>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// };

// export default Login;



import React, { useState } from "react";
import { Form, Button, Container, Row, Col } from "react-bootstrap";
import HeaderNavbar from "../component/HeaderNavbar";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";
import logo from "../assets/el_logo.png";

import { useDispatch, useSelector } from 'react-redux';
import { loginUser } from '../features/authSlice'; // Import loginUser action


const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate(); 

  const { loading, error } = useSelector((state) => state.auth); // Get loading and error states from Redux

  const [userdata, setUserData] = useState({
    email: "",
    password: "",
  });

  console.log(userdata);

  const [isHovered, setIsHovered] = useState(false);



  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };


  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!userdata.email || !userdata.password) {
        alert('Both email and password are required.');
        return;
    }
    try {
        const res = await dispatch(loginUser(userdata)).unwrap(); // Dispatch loginUser action
        if (res.status === 200) {
            // Store token in sessionStorage upon successful login
           sessionStorage.setItem('token', res.data.token);
            navigate('/upload'); // Navigate to the upload page or other page
        } else {
            alert('Invalid credentials. Please try again.');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Something went wrong. Please try again later.');
    }
};

  return (
    <div className="login-main">
      <HeaderNavbar />
      <Container
        className="d-flex align-items-center justify-content-end flex-row"
        style={{ width: "100%", height: "calc(100vh - 150px)" }}
      >
        <Row
          className="w-100 py-4 px-2 m-2"
          style={{
            maxWidth: "400px",
            backgroundColor: "rgba(0, 0, 0, 0.8)",
            borderRadius: "8px",
          }}
        >
          <Col>
            <div className="text-center mb-4">
              <img src={logo} alt="OWM Logo" style={{ width: "65px" }} />
              <hr style={{ color: "white", margin: "10px 0px" }} />
              <h3 style={{ color: "white" }}>Sign In</h3>
            </div>
            <Form onSubmit={handleSubmit} className="login-form p-2 rounded">
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Control
                  type="email"
                  placeholder="UserName"
                  name="email"
                  value={userdata.email}
                  onChange={handleChange}
                  className="transparent-input"
                  aria-label="Enter your userName"
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Control
                  type="password"
                  placeholder="Password"
                  name="password"
                  value={userdata.password}
                  onChange={handleChange}
                  className="transparent-input"
                  aria-label="Enter your password"
                />
              </Form.Group>

              <Button
                variant="primary"
                type="submit"
                className="w-100"
                style={{
                  backgroundColor: isHovered
                    ? "rgba(255, 255, 255, 0.2)"
                    : "rgba(255, 255, 255, 0.1)",
                  border: "1px solid rgba(255, 255, 255, 0.3)",
                  color: "white",
                  transition: "background-color 0.3s ease",
                }}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                disabled={loading}
              >
                {loading ? 'Logging in....' : 'Login'}

              </Button>
              <div className="text-center mt-3">
                <Link
                  to="/forgetPassword"
                  style={{
                    color: "white",
                    fontSize: "12px",
                    cursor: "pointer",
                    textDecoration: "none",
                  }}
                >
                  Forgot Password?
                </Link>
              </div>
            </Form>
            <div className="footer text-center my-3">
              <p style={{ fontSize: "12px", color: "white" }}>
                Powered by{" "}
                <Link
                  to="http://globuslabs.com"
                  style={{ color: "white", textDecoration: "none" }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Globus Labs
                </Link>
              </p>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Login;





































