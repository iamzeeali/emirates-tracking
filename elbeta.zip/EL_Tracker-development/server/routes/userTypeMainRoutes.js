const express = require("express");
const router = express.Router();
const userTypeMainController = require("../controllers/userTypeMainController");

// Add user type main 
router.post("/add", userTypeMainController.addUserTypeMain);

// Get all user type main
router.get("/get", userTypeMainController.getAllUserTypeMain);

module.exports = router;