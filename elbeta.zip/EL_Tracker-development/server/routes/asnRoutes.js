const express = require("express");
const router = express.Router();
const upload = require("../utils/multerConfiguration");
const asnController = require("../controllers/asnController");

//Add asn details by form data
router.post("/", asnController.asnFormData);

// Upload asn excel file to database
router.post("/upload", upload, asnController.asnUploadFile);

// Getting asn details based on Po Doc
router.get("/asnDetails/:poDoc", asnController.getAsnDetailsBasedOnPoDoc);

// Getting asn details on a specific time frame
router.get("/poDetails", asnController.getRecentAsnDetails);

// API to get the latest data insert or upload information
router.get("/latestUpload", asnController.getLastUploadInfo);

module.exports = router;