const express = require("express");
const router = express.Router();
const userTypeController = require("../controllers/userTypeController");

// Add user type
router.post("/add", userTypeController.addUserType);

// Get all user type
router.get("/get", userTypeController.getAllUserType);

module.exports = router;