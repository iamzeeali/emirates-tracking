const express = require("express");
const router = express.Router();
const vendorController = require("../controllers/vendorController");

//Add vendor details
router.post("/add", vendorController.addVendor);

// Getting all vendor details
router.get("/get", vendorController.getAllVendor);

module.exports = router;