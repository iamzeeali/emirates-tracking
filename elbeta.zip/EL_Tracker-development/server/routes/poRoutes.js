const express = require("express");
const router = express.Router();
const poController = require("../controllers/poController");

// Getting status based on PoDoc Number
router.get("/status", poController.getStatusBasedOnPoDoc);

// /api/poDetail?poNumber=4500237290
router.get("/poDetail", poController.getStatusBasedOnPoDetails);

// getting po details on monthly basis 
router.get("/poDetailsMonthly", poController.getpoDetailsMonthly)

// getting po details on monthly basis (DISNT)
router.get("/poDetailsMonthlyDis", poController.getpoDetailsMonthlyDis)


// Getting ecci collection table On monthly basis
router.get("/collectionTable", poController.getEcciCollectionTable);

// Getting ecci dispatch table On monthly basis
router.get("/dispatchTable", poController.getEcciDispatchTable);

// Getting Ecci Diagonal Chart On Monthly basis
router.get("/diagonalChart", poController.getEcciDiagonalChart);

module.exports = router;