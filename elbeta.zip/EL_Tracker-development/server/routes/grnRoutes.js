const express = require("express");
const router = express.Router();
const upload = require("../utils/multerConfiguration");
const grnController = require("../controllers/grnController");

//Add grn details by form data
router.post("/", grnController.grnFormData);

// Upload grn excel file to database
router.post("/upload", upload, grnController.grnUploadFile);

// Getting asn details based on po doc
router.get("/grnDetails/:poDoc", grnController.getGrnDetailsBasedOnPoDoc);

// Getting asn details on a specific time frame
router.get("/poDetails", grnController.getRecentGrnDetails);

// API to get the latest data insert or upload information
router.get("/latestUpload", grnController.getLastUploadInfo);

module.exports = router;