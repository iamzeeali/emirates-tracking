const express = require("express");
const router = express.Router();
const userController = require("../controllers/userController");
const { verifyToken } = require("../middleware/authMiddleware");

// Add user
router.post("/add", userController.addUser);

// get all user
router.get("/get", userController.getAllUser);

// get user by Id
router.get("/get/:userId", userController.getUserById);

// get all user details
router.get("/allDetails", userController.getAllUserDetails);

// update user's status
router.patch("/status/:userId", userController.toggleUserStatus);

// update user's type or role
router.patch("/updateType/:userId", userController.toggleUserType);

// Login user
router.post("/login", userController.loginUser);

// forget password
router.post("/forgetPassword", userController.forgetPassword);

// reset password
router.post("/resetPassword/:token", userController.resetPassword);

// Logout user
router.post("/logout", userController.logoutUser);

module.exports = router;