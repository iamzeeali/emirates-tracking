const { sql } = require("../db");
const getSqlRequest = require("../utils/dbUtil");

// Adding new vendor
exports.addVendor = async (req, res) => {
    try {
      const request = getSqlRequest();
  
      request.input("vendorCode", sql.NVarChar, req.body.vendorCode);
      request.input("vendorName", sql.NVarChar, req.body.vendorName);
      request.input("vendorAddress1", sql.NVarChar, req.body.vendorAddress1);
      request.input("city", sql.NVarChar, req.body.city);
      request.input("pinZip", sql.NVarChar, req.body.pinZip);
      request.input("country", sql.NVarChar, req.body.country);
      request.input("email", sql.NVarChar, req.body.email);
      request.input("phone", sql.NVarChar, req.body.phone);
      request.input("website", sql.NVarChar, req.body.website);
      request.input("contactPerson", sql.NVarChar, req.body.contactPerson);
      request.input("cpMobile", sql.NVarChar, req.body.cpMobile);
      request.input("cpEmail", sql.NVarChar, req.body.cpEmail);
  
      const query = `
        INSERT INTO el_3pl_tracking_tb_vendorMaster_v1
        (vendorCode, vendorName, vendorAddress1, city, pinZip, country, email, phone, website, contactPerson, cpMobile, cpEmail)
    VALUES 
        (@vendorCode, @vendorName, @vendorAddress1, @city, @pinZip, @country, @email, @phone, @website, @contactPerson, @cpMobile, @cpEmail);
      `;
      await request.query(query);
  
      return res.status(201).json({ message: "New vendor added successfully" });
    } catch (error) {
        console.error("Error adding new vendor:", error);
        return res.status(500).json({ message: "Error adding new vendor", data: error });
    }
};

// Getting all vendor
exports.getAllVendor = async (req, res) => {  
  try {
    const request = getSqlRequest();
    const query = `
            SELECT *
            FROM el_3pl_tracking_tb_vendorMaster_v1;
        `;
    const result = await request.query(query);

    if (result.recordset.length > 0) {
      res.json(result.recordset);
    } else {
      res.status(404).send("No data found in vendor table");
    }
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};
