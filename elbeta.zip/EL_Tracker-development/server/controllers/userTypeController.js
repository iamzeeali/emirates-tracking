const { sql } = require("../db");
const getSqlRequest = require("../utils/dbUtil");

// Adding new user type
exports.addUserType = async (req, res) => {
    try {
      const request = getSqlRequest();
  
      request.input("userTypeId", sql.NVarChar, req.body.userTypeId);
      request.input("userType", sql.NVarChar, req.body.userType);

      const query = `
        INSERT INTO el_3pl_tracking_tb_userType_v1
        (userTypeId, userType)
    VALUES 
        (@userTypeId, @userType);
      `;
      await request.query(query);
  
      return res.status(201).json({ message: "New userType added successfully" });
    } catch (error) {
        console.error("Error adding new userType:", error);
        return res.status(500).json({ message: "Error adding new userType", data: error });
    }
};

// Getting all user type
exports.getAllUserType = async (req, res) => {  
    try {
      const request = getSqlRequest();
      const query = `
              SELECT *
              FROM el_3pl_tracking_tb_userType_v1;
          `;
      const result = await request.query(query);
  
      if (result.recordset.length > 0) {
        res.json(result.recordset);
      } else {
        res.status(404).send("No data found in the user type table");
      }
    } catch (err) {
      console.error("SQL error:", err);
      res.status(500).send("Internal Server Error");
    }
};
