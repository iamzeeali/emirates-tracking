const { sql } = require("../db");
const excelToJson = require("convert-excel-to-json");
const getSqlRequest = require("../utils/dbUtil");
const moment = require("moment");


// Add ASN details via form data
exports.asnFormData = async (req, res) => {
  try {
    const request = getSqlRequest();
    // Add all required inputs
    request.input("poDoc", sql.NVarChar, req.body.poDoc);
    request.input("docDate", sql.Date, req.body.docDate);
    request.input("asnUploadDate", sql.Date, req.body.asnUploadDate);
    request.input("material", sql.NVarChar, req.body.material); 
    request.input("vendorCode", sql.NVarChar, req.body.vendorCode);
    request.input("packageType", sql.NVarChar, req.body.packageType); 
    request.input("deliveryPlant", sql.NVarChar, req.body.deliveryPlant); 
    request.input("uploadedAt", sql.Date, new Date()); 
    request.input("uploadedBy", sql.NVarChar, req.body.uploadedBy);

    // SQL query for insertion
    const query = `
      INSERT INTO el_3pl_tracking_tb_asn_v1
      (poDoc, docDate, asnUploadDate, material, vendorCode, packageType,deliveryPlant, uploadedAt, uploadedBy)
      VALUES (@poDoc, @docDate, @asnUploadDate, @material, @vendorCode, @packageType,@deliveryPlant, @uploadedAt, @uploadedBy)
    `;

    await request.query(query);

    // Success response
    return res.status(201).json({ message: "ASN details added successfully." });
  } catch (error) {
    console.error("Error adding ASN details:", error);
    return res
      .status(500)
      .json({ message: "Error adding ASN details.", error: error.message });
  }
};

// Upload asn excel file to the database
exports.asnUploadFile = async (req, res) => {
  try {
    const file = req.file;

    console.log("file");
    

    // Check if file is missing
    if (!file) {
      return res.status(400).json({ error: "File is missing" });
    }

    // Check if the file name is not as expected
    if (file.originalname !== "asn_rep22246.xlsx") {
      return res
        .status(400)
        .json({ error: "Invalid file name. Expected asn_rep22246.xlsx" });
    }

    // Get the uploadedBy from the request body
    const { uploadedBy } = req.body;
    if (!uploadedBy) {
      return res.status(400).json({ error: "uploadedBy field is missing" });
    }

    // Get the current date for uploadedAt
    const uploadedAt = new Date();

    const excelData = excelToJson({
      sourceFile: file.path,
      header: {
        rows: 1,
      },
    });

    if (
      !excelData ||
      !excelData["Sheet1"] ||
      !Array.isArray(excelData["Sheet1"])
    ) {
      return res
        .status(400)
        .json({ error: "Invalid Excel format or missing sheet" });
    }

    const allRowsData = excelData["Sheet1"];

    if (allRowsData.length === 0) {
      return res.status(400).json({ error: "Excel file is empty" });
    }

    const columnToKey = {
      A: "poDoc",
      B: "material",
      C: "docDate",
      D: "asnUploadDate",
      I: "vendorCode",
      O: "deliveryPlant",
      Q: "packageType",
    };

    // Map the rows to jsonData
    const jsonData = allRowsData.map((row) => {
      const jsonRow = {};
      Object.keys(columnToKey).forEach((col) => {
        jsonRow[columnToKey[col]] =
          row[col] !== undefined && row[col] !== null
            ? row[col].toString()
            : null;
      });

      // Correct the asnUploadDate specifically if there's a timezone or off-by-one issue
      if (jsonRow.docDate) {
        const date = new Date(jsonRow.docDate);
        date.setSeconds(date.getSeconds() + 10); 
        jsonRow.docDate = moment(date).format('YYYY/MM/DD HH:mm:ss');
      }
      if (jsonRow.asnUploadDate) {
        const date = new Date(jsonRow.asnUploadDate);
        date.setSeconds(date.getSeconds() + 10); 
        jsonRow.asnUploadDate = moment(date).format('YYYY/MM/DD HH:mm:ss');
      }

      return jsonRow;
    });

    // Add uploadedBy and uploadedAt to each entry in jsonData
    const asnExcelData = jsonData.map((el) => {
      return {
        ...el,
        uploadedAt: uploadedAt,
        uploadedBy: uploadedBy,
      };
    });

    // Continue processing after adding uploadedBy and uploadedAt
    let successCount = 0;
    let duplicateCount = 0;
    const totalRecords = asnExcelData.length;

    for (const asnData of asnExcelData) {
      try {
        const request = getSqlRequest();
        // Insert each record into the database
        await request
          .input("poDoc", sql.NVarChar, asnData.poDoc)
          .input("material", sql.NVarChar, asnData.material)
          .input("docDate", sql.DateTime, asnData.docDate)
          .input("asnUploadDate", sql.DateTime, asnData.asnUploadDate)
          .input("vendorCode", sql.NVarChar, asnData.vendorCode)
          .input("deliveryPlant", sql.NVarChar, asnData.deliveryPlant)
          .input("packageType", sql.NVarChar, asnData.packageType)
          .input("uploadedAt", sql.DateTime, asnData.uploadedAt)
          .input("uploadedBy", sql.NVarChar, asnData.uploadedBy)
          .query(
            `INSERT INTO el_3pl_tracking_tb_asn_v1 
              (poDoc, material, docDate, asnUploadDate, vendorCode, deliveryPlant, packageType, uploadedAt, uploadedBy) 
            VALUES 
              (@poDoc, @material, @docDate, @asnUploadDate, @vendorCode, @deliveryPlant, @packageType, @uploadedAt, @uploadedBy)`
          );
        successCount++;
      } catch (err) {
        console.error(`Error inserting row: ${err.message}`);
        return res.status(500).json({ error: "Internal Server Error" });
      }
    }

    // Return response
    res.status(200).json([
      {
        message: "File uploaded and data inserted successfully",
        totalRecords,
        successCount,
        duplicateCount,
      },
    ]);
  } catch (err) {
    console.error(`Error processing file: ${err.message}`);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Getting asn details based on Ecci Number
exports.getAsnDetailsBasedOnPoDoc = async (req, res) => {
  const { poDoc } = req.params;
  if (!poDoc) {
    return res.status(400).send("PO doc is required");
  }

  try {
    const request = getSqlRequest();
    const query = `
            SELECT *
            FROM el_3pl_tracking_tb_asn_v1
            WHERE poDoc = @poDoc;
        `;
    request.input("poDoc", sql.NVarChar, poDoc);
    const result = await request.query(query);

    if (result.recordset.length > 0) {
      res.json(result.recordset);
    } else {
      res.status(404).send("No data found for the specified po doc");
    }
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};

// Getting recent asn details
exports.getRecentAsnDetails = async (req, res) => {
  const { search = "", page = 1, perPage = 100 } = req.query;

  // Calculate offset based on page number
  const offset = (page - 1) * perPage;

  try {
    const request = new sql.Request();

    // Set search parameter for LIKE condition
    const searchQuery = `%${search}%`;

    // SQL query for search and pagination with ORDER BY clause
    const query = `
          SELECT a.*, v.vendorName
          FROM el_3pl_tracking_tb_asn_v1 a
          JOIN el_3pl_tracking_tb_vendorMaster_v1 v
          ON
          a.vendorCode = v.vendorCode
          WHERE 
              DATEDIFF(DAY, a.asnUploadDateLT, GETDATE()) <= 150
              AND (
                  a.poDoc LIKE @searchQuery OR 
                  a.vendorCode LIKE @searchQuery OR 
                  v.vendorName LIKE @searchQuery
              )
          ORDER BY a.asnUploadDateLT DESC 
          OFFSET @offset ROWS
          FETCH NEXT @perPage ROWS ONLY;
      `;

    // Input parameters for SQL query
    request.input("searchQuery", sql.NVarChar, searchQuery);
    request.input("offset", sql.Int, offset);
    request.input("perPage", sql.Int, parseInt(perPage, 10));

    // Execute the query
    const result = await request.query(query);

    // Check if results are empty
    if (result.recordset.length === 0) {
      return res.json({
        page: parseInt(page, 10),
        perPage: parseInt(perPage, 10),
        results: [],
        message: "No data found in the specified condition.",
      });
    }

    // Return paginated results
    res.json({
      page: parseInt(page, 10),
      perPage: parseInt(perPage, 10),
      results: result.recordset,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// API to get the latest data insert or upload information
exports.getLastUploadInfo = async (req, res) => {
  try {
    // Create a new SQL request
    const request = getSqlRequest();

    // Query to retrieve the latest record based on uploadedAt timestamp
    const result = await request.query(
      `SELECT TOP 1 uploadedBy,
        uploadedAt FROM el_3pl_tracking_tb_asn_v1
        ORDER BY uploadedAt DESC;`
    );

    // Check if any result was found
    if (result.recordset.length === 0) {
      return res.status(404).json({ message: "No records found" });
    }

    // Return the latest upload information
    const latestRecord = result.recordset[0];
    res.status(200).json({
      message: "Latest record details",
      uploadedBy: latestRecord.uploadedBy,
      uploadedAt: latestRecord.uploadedAt,
    });
  } catch (err) {
    console.error(`Error retrieving latest record: ${err.message}`);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
