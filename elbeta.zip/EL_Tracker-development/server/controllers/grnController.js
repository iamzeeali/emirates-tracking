const { sql } = require("../db");
const excelToJson = require("convert-excel-to-json");
const getSqlRequest = require("../utils/dbUtil");
const moment = require("moment");

//Add grn details by form data
exports.grnFormData = async (req, res) => {
  try {
    const request = getSqlRequest();
    // Inputs from request body
    request.input("poDoc", sql.NVarChar, req.body.poDoc);
    request.input("vendorCode", sql.NVarChar, req.body.vendorCode);
    request.input("itemCode", sql.NVarChar, req.body.itemCode);
    request.input("transactionType", sql.NVarChar, req.body.transactionType);
    request.input("modeOfDelivery", sql.NVarChar, req.body.modeOfDelivery);
    request.input("inDate", sql.Date, req.body.inDate); 
    request.input("transDate", sql.Date, req.body.transDate);
    request.input("invoiceNumber", sql.NVarChar, req.body.invoiceNumber); 
    request.input("invoiceValue", sql.NVarChar, req.body.invoiceValue);
    request.input("invoiceDate", sql.Date, req.body.invoiceDate); 
    request.input("deliveryPlant", sql.NVarChar, req.body.deliveryPlant); 
    request.input("uploadedAt", sql.Date, new Date()); 
    request.input("uploadedBy", sql.NVarChar, req.body.uploadedBy);

    // SQL Query for insertion
    const query = `
      INSERT INTO el_3pl_tracking_tb_grn_v1
      (poDoc, vendorCode, itemCode, transactionType, modeOfDelivery, inDate, transDate, invoiceNumber, invoiceValue, invoiceDate, deliveryPlant, uploadedAt, uploadedBy)
      VALUES (@poDoc, @vendorCode,  @itemCode, @transactionType, @modeOfDelivery, @inDate, @transDate, @invoiceNumber, @invoiceValue, @invoiceDate, @deliveryPlant, @uploadedAt, @uploadedBy)
    `;

    // Execute the query
    await request.query(query);

    // Send success response
    return res.status(201).json({ message: "Added new GRN successfully" });
  } catch (error) {
    console.error("Error adding new GRN:", error); // Detailed error logging
    return res
      .status(500)
      .json({ message: "Error adding new GRN", error: error.message });
  }
};

// Simple grn upload code
exports.grnUploadFile = async (req, res) => {
  try {
    const file = req.file;

    // Check if file is missing
    if (!file) {
      return res.status(400).json({ error: "File is missing" });
    }

    // Check if the file name is not as expected
    if (file.originalname !== "grn_rep22248.xlsx") {
      return res
        .status(400)
        .json({ error: "Invalid file name. Expected grn_rep22248.xlsx" });
    }

    // Get the uploadedBy from the request body
    const { uploadedBy } = req.body;
    if (!uploadedBy) {
      return res.status(400).json({ error: "uploadedBy field is missing" });
    }

    // Get the current date for uploadedAt
    const uploadedAt = new Date();

    const excelData = excelToJson({
      sourceFile: file.path,
      header: {
        rows: 1,
      },
    });

    if (
      !excelData ||
      !excelData["Sheet1"] ||
      !Array.isArray(excelData["Sheet1"])
    ) {
      return res
        .status(400)
        .json({ error: "Invalid Excel format or missing sheet" });
    }

    const allRowsData = excelData["Sheet1"];

    if (allRowsData.length === 0) {
      return res.status(400).json({ error: "Excel file is empty" });
    }

    const columnToKey = {
        D: "transactionType",
        E: "modeOfDelivery",
        F: "itemCode",
        M: "poDoc",
        N: "invoiceNumber",
        O: "invoiceDate",
        P: "invoiceValue",
        Q: "vendorCode",
        T: "inDate",
        W: "deliveryPlant",
        AK: "transDate",
      };

    // Map the rows to jsonData
    const jsonData = allRowsData.map((row) => {
      const jsonRow = {};
      Object.keys(columnToKey).forEach((col) => {
        jsonRow[columnToKey[col]] =
          row[col] !== undefined && row[col] !== null
            ? row[col].toString()
            : null;
      });

      // Convert inDate & transDate to dd/mm/yyyy format
      if (jsonRow.inDate) {
        const date = new Date(jsonRow.inDate);
        date.setSeconds(date.getSeconds() + 10);
        jsonRow.inDate = moment(date).format("YYYY/MM/DD HH:mm:ss");
      }
      if (jsonRow.transDate) {
        const date = new Date(jsonRow.transDate);
        date.setSeconds(date.getSeconds() + 10);
        jsonRow.transDate = moment(date).format("YYYY/MM/DD HH:mm:ss");
      }
      if (jsonRow.invoiceDate) {
        const date = new Date(jsonRow.invoiceDate);
        date.setSeconds(date.getSeconds() + 10);
        jsonRow.invoiceDate = moment(date).format("YYYY/MM/DD HH:mm:ss");
      }
      return jsonRow;
    });

    // Add uploadedBy and uploadedAt to each entry in jsonData
    const grnExcelData = jsonData.map((el) => {
      return {
        ...el,
        uploadedAt: uploadedAt,
        uploadedBy: uploadedBy,
      };
    })

    // Continue processing after adding uploadedBy and uploadedAt
    let successCount = 0;
    let duplicateCount = 0;
    const totalRecords = grnExcelData.length;

    for (const grnData of grnExcelData) {
      try {
        const request = getSqlRequest();

        // Insert each record into the database
        await request
          .input("transactionType", sql.NVarChar, grnData.transactionType)
          .input("modeOfDelivery", sql.NVarChar, grnData.modeOfDelivery)
          .input("itemCode", sql.NVarChar, grnData.itemCode)
          .input("poDoc", sql.NVarChar, grnData.poDoc)
          .input("invoiceNumber", sql.NVarChar, grnData.invoiceNumber)
          .input("invoiceDate", sql.DateTime, grnData.invoiceDate)
          .input("invoiceValue", sql.NVarChar, grnData.invoiceValue)
          .input("vendorCode", sql.NVarChar, grnData.vendorCode)
          .input("inDate", sql.DateTime, grnData.inDate)
          .input("deliveryPlant", sql.NVarChar, grnData.deliveryPlant)
          .input("transDate", sql.DateTime, grnData.transDate)
          .input("UOM", sql.NVarChar, grnData.UOM)
          .input("qty", sql.Int, grnData.qty)
          .input("dnNumber", sql.NVarChar, grnData.dnNumber)
          .input("uploadedAt", sql.DateTime, grnData.uploadedAt)
          .input("uploadedBy", sql.NVarChar, grnData.uploadedBy)
          .query(
            `INSERT INTO el_3pl_tracking_tb_grn_v1 (transactionType, modeOfDelivery, itemCode, poDoc, invoiceNumber, invoiceDate, invoiceValue, vendorCode, inDate, deliveryPlant, transDate, UOM, qty, dnNumber, uploadedAt, uploadedBy) 
            VALUES (@transactionType, @modeOfDelivery, @itemCode, @poDoc, @invoiceNumber, @invoiceDate, @invoiceValue, @vendorCode, @inDate, @deliveryPlant, @transDate, @UOM, @qty, @dnNumber, @uploadedAt, @uploadedBy
            )`
          );
        successCount++;
      } catch (err) {
        console.error(`Error inserting row: ${err.message}`);
        return res.status(500).json({ error: "Internal Server Error" });
      }
    }

    // Return response
    res.status(200).json([
      {
        message: "File uploaded and data inserted successfully",
        totalRecords,
        successCount,
        duplicateCount,
      },
    ]);
  } catch (err) {
    console.error(`Error processing file: ${err.message}`);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// grn upload with advance collection
// exports.grnUploadFile = async (req, res) => {
//   try {
//     const file = req.file;

//     if (!file) {
//       return res.status(400).json({ error: "File is missing" });
//     }

//     if (file.originalname !== "grn_rep22248.xlsx") {
//       return res.status(400).json({ error: "Invalid file name. Expected grn_rep22248.xlsx" });
//     }

//     const { uploadedBy } = req.body;
//     if (!uploadedBy) {
//       return res.status(400).json({ error: "uploadedBy field is missing" });
//     }

//     const uploadedAt = new Date();

//     const excelData = excelToJson({
//       sourceFile: file.path,
//       header: {
//         rows: 1,
//       },
//     });

//     if (!excelData || !excelData["Sheet1"] || !Array.isArray(excelData["Sheet1"])) {
//       return res.status(400).json({ error: "Invalid Excel format or missing sheet" });
//     }

//     const allRowsData = excelData["Sheet1"];
//     if (allRowsData.length === 0) {
//       return res.status(400).json({ error: "Excel file is empty" });
//     }

//     const columnToKey = {
//       D: "transactionType",
//       E: "modeOfDelivery",
//       F: "itemCode",
//       M: "poDoc",
//       N: "invoiceNumber",
//       O: "invoiceDate",
//       P: "invoiceValue",
//       Q: "vendorCode",
//       T: "inDate",
//       W: "deliveryPlant",
//       AK: "transDate",
//     };

//     const jsonData = allRowsData.map((row) => {
//       const jsonRow = {};
//       Object.keys(columnToKey).forEach((col) => {
//         jsonRow[columnToKey[col]] =
//           row[col] !== undefined && row[col] !== null ? row[col].toString() : null;
//       });

//       // Parse dates with time adjustment
//       if (jsonRow.inDate) {
//         const date = new Date(jsonRow.inDate);
//         date.setSeconds(date.getSeconds() + 10);
//         jsonRow.inDate = moment(date).format("YYYY-MM-DD HH:mm:ss");
//       }
//       if (jsonRow.transDate) {
//         const date = new Date(jsonRow.transDate);
//         date.setSeconds(date.getSeconds() + 10);
//         jsonRow.transDate = moment(date).format("YYYY-MM-DD HH:mm:ss");
//       }
//       if (jsonRow.invoiceDate) {
//         const date = new Date(jsonRow.invoiceDate);
//         date.setSeconds(date.getSeconds() + 10);
//         jsonRow.invoiceDate = moment(date).format("YYYY-MM-DD HH:mm:ss");
//       }

//       return jsonRow;
//     });

//     // Filter and add metadata to valid rows
//     const grnExcelData = jsonData
//       .map((el) => ({
//         ...el,
//         uploadedAt,
//         uploadedBy,
//       }))
//       .filter((row) => row.ecciNumber && row.vendorCode);

//     // Extract ecciNumbers
//     const ecciNumbers = grnExcelData.map((row) => ({
//       ecciNumber: row.ecciNumber,
//       inDate: row.inDate,
//     }));

//     // Step 1: Upload ecciNumbers to a temporary table
//     const request = getSqlRequest();

//     await request.query(`
//       CREATE TABLE ##TempEcciNumbers (
//         ecciNumber NVARCHAR(50),
//         inDate DATETIME
//       )
//     `);

//     for (const { ecciNumber, inDate } of ecciNumbers) {
//       const tempRequest = getSqlRequest(); // New request for each iteration
//       await tempRequest
//         .input("ecciNumber", sql.NVarChar, ecciNumber)
//         .input("inDate", sql.DateTime, inDate)
//         .query(`INSERT INTO ##TempEcciNumbers (ecciNumber, inDate) VALUES (@ecciNumber, @inDate)`);
//     }

//     // Step 2: Find missing ecciNumbers
//     const missingEcciNumbersQuery = `
//       SELECT grn.ecciNumber
//        FROM ##TempEcciNumbers AS grn
//        LEFT JOIN owm_3pl_tracking_tb_asn_v1 AS asn
//        ON grn.ecciNumber = asn.ecciNumber
//        WHERE asn.ecciNumber IS NULL;
//     `;

//     const missingEcciNumbers = await request.query(missingEcciNumbersQuery);

//     // Step 3: Insert missing records into ASN table
//     if (missingEcciNumbers.recordset.length > 0) {
//       const missingRecords = grnExcelData.filter((row) =>
//         missingEcciNumbers.recordset.some((missing) => missing.ecciNumber === row.ecciNumber)
//       );

//       for (const record of missingRecords) {
//         const asnRequest = getSqlRequest(); // New request for each iteration
//         await asnRequest
//           .input("ecciNumber", sql.NVarChar, record.ecciNumber)
//           .input("itemCode", sql.NVarChar, record.itemCode)
//           .input("vendorCode", sql.NVarChar, record.vendorCode)
//           .input("vendorName", sql.NVarChar, record.vendorName)
//           .input("asnUploadDate", sql.DateTime, record.inDate) // Use inDate as asnUploadDate
//           .input("uploadedAt", sql.DateTime, record.uploadedAt)
//           .input("uploadedBy", sql.NVarChar, record.uploadedBy)
//           .input("typeStatus", sql.NVarChar, "GRN")
//           .query(`
//             INSERT INTO owm_3pl_tracking_tb_asn_v1 
//             (ecciNumber, itemCode, vendorCode, vendorName, asnUploadDate, uploadedAt, uploadedBy, typeStatus)
//             VALUES (@ecciNumber, @itemCode, @vendorCode, @vendorName, @asnUploadDate, @uploadedAt, @uploadedBy, @typeStatus)
//           `);
//       }
//     }

//     // Step 4: Insert GRN data
//     let successCount = 0;
//     let duplicateCount = 0;

//     for (const grnData of grnExcelData) {
//       const grnRequest = getSqlRequest(); // New request for each iteration
//       try {
//         await grnRequest
//           .input("ecciNumber", sql.NVarChar, grnData.ecciNumber)
//           .input("itemCode", sql.NVarChar, grnData.itemCode)
//           .input("transactionType", sql.NVarChar, grnData.transactionType)
//           .input("modeOfDelivery", sql.NVarChar, grnData.modeOfDelivery)
//           .input("inDate", sql.DateTime, grnData.inDate)
//           .input("transDate", sql.DateTime, grnData.transDate)
//           .input("vendorCode", sql.NVarChar, grnData.vendorCode)
//           .input("vendorName", sql.NVarChar, grnData.vendorName)
//           .input("uploadedAt", sql.DateTime, grnData.uploadedAt)
//           .input("uploadedBy", sql.NVarChar, grnData.uploadedBy)
//           .query(`
//             INSERT INTO owm_3pl_tracking_tb_grn_v1 (ecciNumber, itemCode, transactionType, modeOfDelivery, inDate, transDate, vendorCode, vendorName, uploadedAt, uploadedBy)
//             VALUES (@ecciNumber, @itemCode, @transactionType, @modeOfDelivery, @inDate, @transDate, @vendorCode, @vendorName, @uploadedAt, @uploadedBy)
//           `);
//         successCount++;
//       } catch (err) {
//         duplicateCount++;
//       }
//     }

//     // Clean up temporary table
//     await request.query(`DROP TABLE ##TempEcciNumbers`);

//     res.status(200).json({
//       message: "File uploaded and data processed successfully",
//       totalRecords: grnExcelData.length,
//       successCount,
//       duplicateCount,
//     });
//   } catch (err) {
//     console.error(`Error processing file: ${err.message}`);
//     res.status(500).json({ error: "Internal Server Error" });
//   }
// };

// Getting grn details based on po doc
exports.getGrnDetailsBasedOnPoDoc = async (req, res) => {
  const { poDoc } = req.params;
  if (!poDoc) {
    return res.status(400).send("Po Doc is required");
  }
  try {
    const request = getSqlRequest();
    const query = `
            SELECT *
            FROM el_3pl_tracking_tb_grn_v1
            WHERE poDoc = @poDoc
            ;
        `;
    request.input("poDoc", sql.NVarChar, poDoc);
    const result = await request.query(query);

    if (result.recordset.length > 0) {
      res.json(result.recordset);
    } else {
      res.status(404).send("No data found for the specified Po Doc");
    }
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};

// Getting recent grn details
exports.getRecentGrnDetails = async (req, res) => {
  const { search = "", page = 1, perPage = 100 } = req.query;

  // Calculate offset based on page number
  const offset = (page - 1) * perPage;

  try {
    const request = new sql.Request();

    // Set search parameter for LIKE condition
    const searchQuery = `%${search}%`;

    // SQL query for search and pagination with ORDER BY clause
    const query = `
          SELECT a.*, v.vendorName
          FROM el_3pl_tracking_tb_grn_v1 a
          JOIN el_3pl_tracking_tb_vendorMaster_v1 v
          ON
          a.vendorCode = v.vendorCode
          WHERE 
              DATEDIFF(DAY, a.inDateLT, GETDATE()) <= 150
              AND (
                  a.poDoc LIKE @searchQuery OR 
                  a.vendorCode LIKE @searchQuery OR 
                  v.vendorName LIKE @searchQuery
              )
          ORDER BY a.inDateLT DESC 
          OFFSET @offset ROWS
          FETCH NEXT @perPage ROWS ONLY;
      `;

    // Input parameters for SQL query
    request.input("searchQuery", sql.NVarChar, searchQuery);
    request.input("offset", sql.Int, offset);
    request.input("perPage", sql.Int, parseInt(perPage, 10));

    // Execute the query
    const result = await request.query(query);

    // Check if results are empty
    if (result.recordset.length === 0) {
      return res.json({
        page: parseInt(page, 10),
        perPage: parseInt(perPage, 10),
        results: [],
        message: "No data found in the specified condition.",
      });
    }

    // Return paginated results
    res.json({
      page: parseInt(page, 10),
      perPage: parseInt(perPage, 10),
      results: result.recordset,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// API to get the latest data insert or upload information
exports.getLastUploadInfo = async (req, res) => {
  try {
    // Create a new SQL request
    const request = getSqlRequest();

    // Query to retrieve the latest record based on uploadedAt timestamp
    const result = await request.query(
      `SELECT TOP 1 uploadedBy,
        uploadedAt FROM el_3pl_tracking_tb_grn_v1
        ORDER BY uploadedAt DESC;`
    );

    // Check if any result was found
    if (result.recordset.length === 0) {
      return res.status(404).json({ message: "No records found" });
    }

    // Return the latest upload information
    const latestRecord = result.recordset[0];
    res.status(200).json({
      message: "Latest record details",
      uploadedBy: latestRecord.uploadedBy,
      uploadedAt: latestRecord.uploadedAt,
    });
  } catch (err) {
    console.error(`Error retrieving latest record: ${err.message}`);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

