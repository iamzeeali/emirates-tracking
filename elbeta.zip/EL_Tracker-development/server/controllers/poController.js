const { sql } = require("../db");
const getSqlRequest = require("../utils/dbUtil");

// Getting Status Based On po doc
exports.getStatusBasedOnPoDoc = async (req, res) => {
  const { poDoc } = req.query;
  if (!poDoc) {
    return res.status(400).send("Po doc is required");
  }
  try {
    const request = getSqlRequest();
    const query = `
    SELECT 
        (SELECT TOP 1 modeOfDelivery 
         FROM el_3pl_tracking_tb_grn_v1
         WHERE poDoc = @poDoc
         ORDER BY inDateLT DESC) AS mode_of_delivery,
        (SELECT TOP 1 deliveryPlant 
         FROM el_3pl_tracking_tb_grn_v1
         WHERE poDoc = @poDoc
         ORDER BY inDateLT DESC) AS delivery_plant,
        (SELECT TOP 1 docDateLT 
         FROM el_3pl_tracking_tb_asn_v1
         WHERE poDoc = @poDoc
         ORDER BY docDateLT DESC) AS po_received_date,
        COALESCE(
          (SELECT TOP 1 inDateLT 
          FROM el_3pl_tracking_tb_grn_v1 
          WHERE poDoc = @poDoc 
          ORDER BY inDateLT DESC),
          DATEADD(DAY, 1, 
          (SELECT TOP 1 asnUploadDateLT 
          FROM el_3pl_tracking_tb_asn_v1 
          WHERE poDoc = @poDoc
          ORDER BY asnUploadDateLT DESC))
        ) AS planned_for_picking,
        (SELECT TOP 1 v.vendorName 
         FROM el_3pl_tracking_tb_asn_v1 a 
         JOIN el_3pl_tracking_tb_vendorMaster_v1 v 
         ON a.vendorCode = v.vendorCode 
         WHERE a.poDoc = @poDoc) AS vendorName,
        (SELECT TOP 1 v.vendorAddress1 
         FROM el_3pl_tracking_tb_asn_v1 a 
         JOIN el_3pl_tracking_tb_vendorMaster_v1 v 
         ON a.vendorCode = v.vendorCode 
         WHERE a.poDoc = @poDoc) AS vendorAddress,
        (SELECT TOP 1 inDateLT 
          FROM el_3pl_tracking_tb_grn_v1 
          WHERE poDoc = @poDoc 
          ORDER BY inDateLT DESC) AS inDateLT,
        (SELECT TOP 1 transDateLT 
          FROM el_3pl_tracking_tb_grn_v1 
          WHERE poDoc = @poDoc 
          ORDER BY transDateLT DESC) AS transDateLT
    WHERE 
        EXISTS (SELECT 1 FROM el_3pl_tracking_tb_asn_v1 WHERE poDoc = @poDoc) 
        OR EXISTS (SELECT 1 FROM el_3pl_tracking_tb_grn_v1 WHERE poDoc = @poDoc);
  `;

    request.input("poDoc", sql.NVarChar, poDoc);
    const result = await request.query(query);

    if (result.recordset.length > 0) {
      res.json(result.recordset);
    } else {
      res.status(404).send("No data found based on given poDoc");
    }
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};

// getting status of particular po
exports.getStatusBasedOnPoDetails = async (req, res) => {
  const { poDoc } = req.query;

  if (!poDoc) {
    return res.status(400).send("Po doc is required");
  }

  try {
    const request = getSqlRequest();
    // SQL Query with Common Table Expression (CTE)
    const query = `
        WITH cte_asn AS (
            SELECT *,
                  ROW_NUMBER() OVER (PARTITION BY poDoc ORDER BY docDateLT) AS rn
            FROM el_3pl_tracking_tb_asn_v1
        ),
        cte_grn AS (
            SELECT *,
                  ROW_NUMBER() OVER (PARTITION BY poDoc ORDER BY inDateLT) AS rn
            FROM el_3pl_tracking_tb_grn_v1
        )
        SELECT 
            a.poDoc,
            a.docDateLT AS po_received_date,
            a.asnUploadDateLT AS planned_for_picking,
            g.inDateLT,
            g.transDateLT,
            g.modeOfDelivery AS deliveryType,
            g.deliveryPlant,
            g.vendorCode,
            v.vendorName
        FROM 
            cte_asn a
        JOIN 
            cte_grn g
        ON 
            a.poDoc = g.poDoc AND a.rn = g.rn
        LEFT JOIN 
          el_3pl_tracking_tb_vendorMaster_v1 v
        ON 
          g.vendorCode = v.vendorCode
        WHERE 
            a.poDoc = @poDoc
            AND a.material = g.itemCode;
    `;

    // Use parameterized query to prevent SQL injection
    request.input("poDoc", sql.NVarChar, poDoc);

    // Execute query
    const result = await request.query(query);

    // If no result is found, respond with 404
    if (result.recordset.length === 0) {
      return res.status(404).send("No details found for the given poDoc");
    }

    // Send the result back as JSON
    res.status(200).json(result.recordset);
  } catch (error) {
    // Log error for debugging
    console.error("Error fetching details:", error);
    res.status(500).send("An error occurred while fetching data");
  }
};

// getting po details on monthly basis
exports.getpoDetailsMonthly = async (req, res) => {
  const { search = "", page = 1, perPage = 10 } = req.query; 

  // Calculate offset based on page number
  const offset = (page - 1) * perPage;

  try {
    const request = new sql.Request();

    // Set search parameter for LIKE condition
    const searchQuery = `%${search}%`;

    // SQL query for search, pagination, and filtering
    const query = `
      WITH CombinedData AS (
        SELECT 
          ISNULL(a.YearMonth, g.YearMonth) AS YearMonth,
          ISNULL(a.poDoc, 0) AS poDoc_Of_Asn,
          ISNULL(g.poDoc, 0) AS poDoc_Of_Grn
        FROM (
          SELECT 
            FORMAT(asnUploadDateLT, 'yyyy-MM') AS YearMonth,
            COUNT( poDoc) AS poDoc
          FROM el_3pl_tracking_tb_asn_v1
          GROUP BY FORMAT(asnUploadDateLT, 'yyyy-MM')
        ) a
        FULL OUTER JOIN (
          SELECT 
            FORMAT(inDateLT, 'yyyy-MM') AS YearMonth,
            COUNT( poDoc) AS poDoc
          FROM el_3pl_tracking_tb_grn_v1
          GROUP BY FORMAT(inDateLT, 'yyyy-MM')
        ) g
        ON a.YearMonth = g.YearMonth
      )
      SELECT * 
      FROM CombinedData
      WHERE YearMonth LIKE @searchQuery
      ORDER BY YearMonth
      OFFSET @offset ROWS FETCH NEXT @perPage ROWS ONLY;
    `;

    // Input parameters for SQL query
    request.input("searchQuery", sql.NVarChar, searchQuery);
    request.input("offset", sql.Int, offset);
    request.input("perPage", sql.Int, perPage);

    // Execute the query
    const result = await request.query(query);

    // Check if results are empty
    if (result.recordset.length === 0) {
      return res.json({
        page: parseInt(page, 10),
        perPage: parseInt(perPage, 10),
        results: [],
        message: "No data found in the specified condition.",
      });
    }

    // Return paginated results
    res.json({
      page: parseInt(page, 10),
      perPage: parseInt(perPage, 10),
      results: result.recordset,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// getting po details on monthly basis use (DISNT)
exports.getpoDetailsMonthlyDis = async (req, res) => {
  const { search = "", page = 1, perPage = 10 } = req.query; 

  // Calculate offset based on page number
  const offset = (page - 1) * perPage;

  try {
    const request = new sql.Request();

    // Set search parameter for LIKE condition
    const searchQuery = `%${search}%`;

    // SQL query for search, pagination, and filtering
    const query = `
      WITH CombinedData AS (
        SELECT 
          ISNULL(a.YearMonth, g.YearMonth) AS YearMonth,
          ISNULL(a.poDoc, 0) AS poDoc_Of_Asn,
          ISNULL(g.poDoc, 0) AS poDoc_Of_Grn
        FROM (
          SELECT 
            FORMAT(asnUploadDateLT, 'yyyy-MM') AS YearMonth,
            COUNT(DISTINCT poDoc) AS poDoc
          FROM el_3pl_tracking_tb_asn_v1
          GROUP BY FORMAT(asnUploadDateLT, 'yyyy-MM')
        ) a
        FULL OUTER JOIN (
          SELECT 
            FORMAT(inDateLT, 'yyyy-MM') AS YearMonth,
            COUNT(DISTINCT poDoc) AS poDoc
          FROM el_3pl_tracking_tb_grn_v1
          GROUP BY FORMAT(inDateLT, 'yyyy-MM')
        ) g
        ON a.YearMonth = g.YearMonth
      )
      SELECT * 
      FROM CombinedData
      WHERE YearMonth LIKE @searchQuery
      ORDER BY YearMonth
      OFFSET @offset ROWS FETCH NEXT @perPage ROWS ONLY;
    `;

    // Input parameters for SQL query
    request.input("searchQuery", sql.NVarChar, searchQuery);
    request.input("offset", sql.Int, offset);
    request.input("perPage", sql.Int, perPage);

    // Execute the query
    const result = await request.query(query);

    // Check if results are empty
    if (result.recordset.length === 0) {
      return res.json({
        page: parseInt(page, 10),
        perPage: parseInt(perPage, 10),
        results: [],
        message: "No data found in the specified condition.",
      });
    }

    // Return paginated results
    res.json({
      page: parseInt(page, 10),
      perPage: parseInt(perPage, 10),
      results: result.recordset,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Getting ecci collection table On monthly basis
exports.getEcciCollectionTable = async (req, res) => {
  const { date } = req.query;
  if (!date) {
    return res.status(400).send("Date is required");
  }

  try {
    const endDate = new Date(date); // Convert the provided date to a Date object

    const startDay = endDate.getDate(); // Extract the day part

    const resultsArray = [];

    // Loop from the provided day down to the first day of the month
    for (let day = startDay; day >= 1; day--) {
      const currentDate = new Date(
        endDate.getFullYear(),
        endDate.getMonth(),
        day
      );

      const formattedDate = `${currentDate.getFullYear()}-${String(
        currentDate.getMonth() + 1
      ).padStart(2, "0")}-${String(currentDate.getDate()).padStart(2, "0")}`;

      const request = getSqlRequest();
      const query = `
        SELECT 
          (SELECT COUNT(DISTINCT poDoc) 
            FROM owm_3pl_tracking_tb_asn_v1
            WHERE CAST(asnUploadDateLT AS DATE) = @date
          ) AS ECCI_Count,
          
          (SELECT COUNT(DISTINCT asn.ecciNumber)
            FROM owm_3pl_tracking_tb_asn_v1 asn
            WHERE asn.asnUploadDateLT < @date 
            AND NOT EXISTS (
                      SELECT 1
                      FROM owm_3pl_tracking_tb_grn_v1 grn
                      WHERE grn.ecciNumber = asn.ecciNumber
                      AND grn.inDateLT < @date )
          ) AS backlog_ecciNumber,
          
          (SELECT COUNT(DISTINCT asn.ecciNumber)
            FROM owm_3pl_tracking_tb_asn_v1 asn
            JOIN owm_3pl_tracking_tb_grn_v1 grn
                ON asn.ecciNumber = grn.ecciNumber
            WHERE CAST(asn.asnUploadDateLT AS DATE) = @date
              AND CAST(grn.inDateLT AS DATE) = @date
          ) AS ecci_Collection_On_Same_Day,
          
          (SELECT COUNT(DISTINCT asn.ecciNumber)
            FROM owm_3pl_tracking_tb_asn_v1 asn
            JOIN owm_3pl_tracking_tb_grn_v1 grn
                ON asn.ecciNumber = grn.ecciNumber
            WHERE CAST(grn.inDateLT AS DATE) = @date
          ) AS ecci_Collection_On_This_Date
      `;

      request.input("date", sql.NVarChar, formattedDate);
      const result = await request.query(query);

      if (result.recordset.length > 0) {
        const Number_Of_ECCI_for_Collection = result.recordset[0].ECCI_Count;
        const Number_Of_Backlog_ECCI = result.recordset[0].backlog_ecciNumber;
        const Total_Number_Of_ECCI_for_Collection =
          Number_Of_ECCI_for_Collection + Number_Of_Backlog_ECCI;
        const No_Of_ECCI_Collected_On_Same_Day =
          result.recordset[0].ecci_Collection_On_Same_Day;
        const Total_No_Of_ECCI_Collected_With_Backlog =
          result.recordset[0].ecci_Collection_On_This_Date;
        const No_Of_Backlog_ECCI_Collected_On_This_Day =
          Total_No_Of_ECCI_Collected_With_Backlog - No_Of_ECCI_Collected_On_Same_Day;
        const No_Of_ECCI_Collected_Within_24_hrs =
          No_Of_ECCI_Collected_On_Same_Day;
        const No_Of_ECCI_Collected_After_24_hrs =
          Total_No_Of_ECCI_Collected_With_Backlog -
          No_Of_ECCI_Collected_On_Same_Day;
        const Percentage_OF_ECCI_Collection_On_Same_Day =
          (No_Of_ECCI_Collected_On_Same_Day / Number_Of_ECCI_for_Collection) *
          100;
        const Not_Collected_ECCI_Of_Current_Date =
          Number_Of_ECCI_for_Collection - No_Of_ECCI_Collected_On_Same_Day;
        const Total_No_Of_Not_Collected_ECCI =
          Total_Number_Of_ECCI_for_Collection -
          Total_No_Of_ECCI_Collected_With_Backlog;
        const Not_Collected_ECCI_Of_Previous_Date =
          Total_No_Of_Not_Collected_ECCI - Not_Collected_ECCI_Of_Current_Date;

        resultsArray.push({
          date: formattedDate,
          Number_Of_ECCI_for_Collection,
          Number_Of_Backlog_ECCI,
          Total_Number_Of_ECCI_for_Collection,
          No_Of_ECCI_Collected_On_Same_Day,
          No_Of_Backlog_ECCI_Collected_On_This_Day,
          Total_No_Of_ECCI_Collected_With_Backlog,
          No_Of_ECCI_Collected_Within_24_hrs,
          No_Of_ECCI_Collected_After_24_hrs,
          Percentage_OF_ECCI_Collection_On_Same_Day,
          Total_No_Of_Not_Collected_ECCI,
          Not_Collected_ECCI_Of_Previous_Date,
          Not_Collected_ECCI_Of_Current_Date,
        });
      } else {
        resultsArray.push({
          date: formattedDate,
          message: "No data found based on given date",
        });
      }
    }

    // Send all the results for each date in the range
    res.json(resultsArray);
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};

// Getting ecci dispatch table On monthly basis
exports.getEcciDispatchTable = async (req, res) => {
  const { date } = req.query;
  if (!date) {
    return res.status(400).send("Date is required");
  }

  try {
    const endDate = new Date(date); // Convert the provided date to a Date object

    const startDay = endDate.getDate(); // Extract the day part

    const resultsArray = [];

    // Loop from the provided day down to the first day of the month
    for (let day = startDay; day >= 1; day--) {
      const currentDate = new Date(
        endDate.getFullYear(),
        endDate.getMonth(),
        day
      );
      // currentDate.getMonth() + 1 'Because of zero based indexing'
      const formattedDate = `${currentDate.getFullYear()}-${String(
        currentDate.getMonth() + 1
      ).padStart(2, "0")}-${String(currentDate.getDate()).padStart(2, "0")}`;

      const request = getSqlRequest();
      const query = `
            SELECT 
              (SELECT COUNT(DISTINCT ecciNumber) 
              FROM owm_3pl_tracking_tb_grn_v1
              WHERE CAST(inDateLT AS DATE) = DATEADD(day, -1, @date)
              ) AS ECCI_Count,
        
              (SELECT COUNT(DISTINCT ecciNumber) 
                FROM owm_3pl_tracking_tb_grn_v1
                WHERE 
                inDateLT < DATEADD(day, -1, @date)  AND
                (transDateLT IS NULL OR transDateLT > @date)
              )AS backlog_count,
        
              (SELECT COUNT(DISTINCT ecciNumber)
                FROM owm_3pl_tracking_tb_grn_v1
                WHERE CAST(inDateLT AS DATE) = DATEADD(day, -1, @date)
                  AND CAST(transDateLT AS DATE) = @date
              ) AS ecci_dispatched_On_Same_Day,
        
              (SELECT COUNT(DISTINCT ecciNumber)
                FROM owm_3pl_tracking_tb_grn_v1
                WHERE CAST(transDateLT AS DATE) = @date
              ) AS ecci_dispatched_On_This_Date
          `;

      request.input("date", sql.NVarChar, formattedDate);
      const result = await request.query(query);

      if (result.recordset.length > 0) {
        const Number_Of_ECCI_for_dispatch = result.recordset[0].ECCI_Count;
        const Number_Of_Backlog_ECCI = result.recordset[0].backlog_count;
        const Total_Number_Of_ECCI_for_dispatch =
          Number_Of_ECCI_for_dispatch + Number_Of_Backlog_ECCI;
        const No_Of_ECCI_Dispatched_On_Same_Day =
          result.recordset[0].ecci_dispatched_On_Same_Day;
        const Total_No_Of_ECCI_Dispatched_With_Backlog =
          result.recordset[0].ecci_dispatched_On_This_Date;
        const No_Of_backlog_ECCI_for_Dispatched = Total_No_Of_ECCI_Dispatched_With_Backlog - No_Of_ECCI_Dispatched_On_Same_Day;
        const No_ECCI_Dispatched_Within_24_hrs =
          No_Of_ECCI_Dispatched_On_Same_Day;
        const No_ECCI_Dispatched_After_24_hrs =
          Total_No_Of_ECCI_Dispatched_With_Backlog - No_Of_ECCI_Dispatched_On_Same_Day;
        const Percentage_OF_ECCI_dispatch_On_Same_Day =
          (No_Of_ECCI_Dispatched_On_Same_Day / Number_Of_ECCI_for_dispatch) *
          100;
        const Not_Dispatched_ECCI_Of_Current_Date =
          Number_Of_ECCI_for_dispatch - No_Of_ECCI_Dispatched_On_Same_Day;
        const Total_No_Of_Not_Dispatched_ECCI =
          Total_Number_Of_ECCI_for_dispatch -
          Total_No_Of_ECCI_Dispatched_With_Backlog;
        const Not_Dispatched_ECCI_Of_Previous_Date =
          Total_No_Of_Not_Dispatched_ECCI - Not_Dispatched_ECCI_Of_Current_Date;

        resultsArray.push({
          date: formattedDate,
          Number_Of_ECCI_for_dispatch,
          Number_Of_Backlog_ECCI,
          Total_Number_Of_ECCI_for_dispatch,
          No_Of_ECCI_Dispatched_On_Same_Day,
          No_Of_backlog_ECCI_for_Dispatched,
          Total_No_Of_ECCI_Dispatched_With_Backlog,
          No_ECCI_Dispatched_Within_24_hrs,
          No_ECCI_Dispatched_After_24_hrs,
          Percentage_OF_ECCI_dispatch_On_Same_Day,
          Total_No_Of_Not_Dispatched_ECCI,
          Not_Dispatched_ECCI_Of_Previous_Date,
          Not_Dispatched_ECCI_Of_Current_Date,
        });
      } else {
        resultsArray.push({
          date: formattedDate,
          message: "No data found based on given date",
        });
      }
    }

    // Send all the results for each date in the range
    res.json(resultsArray);
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};

// Getting Ecci Diagonal Chart
exports.getEcciDiagonalChart = async (req, res) => {
  const { date } = req.query;
  if (!date) {
    return res.status(400).send("Date is required");
  }

  try {
    const endDate = new Date(date);
    const startDay = endDate.getDate();

    const resultsArray = [];

    for (let day = startDay; day >= 1; day--) {
      const currentDate = new Date(
        endDate.getFullYear(),
        endDate.getMonth(),
        day
      );

      const formattedDate = `${currentDate.getFullYear()}-${String(
        currentDate.getMonth() + 1
      ).padStart(2, "0")}-${String(currentDate.getDate()).padStart(2, "0")}`;

      const request = getSqlRequest();
      const query = `
        WITH ASN_Count AS (
          SELECT COUNT(DISTINCT ecciNumber) AS EcciCount
          FROM owm_3pl_tracking_tb_asn_v1
          WHERE CAST(asnUploadDateLT AS DATE) = @date
        )
        SELECT DISTINCT
          ac.EcciCount,
          a.asnUploadDateLT,
          g.inDateLT,
          g.ecciNumber
        FROM 
          owm_3pl_tracking_tb_asn_v1 a
        LEFT JOIN 
          owm_3pl_tracking_tb_grn_v1 g ON a.ecciNumber = g.ecciNumber
        CROSS JOIN 
          ASN_Count ac
        WHERE 
          CAST(a.asnUploadDateLT AS DATE) = @date
        ORDER BY 
          g.inDateLT;
      `;

      request.input("date", sql.NVarChar, formattedDate);
      const result = await request.query(query);

      if (result.recordset.length > 0) {
        const EcciCount = result.recordset[0].EcciCount;

        // Group by `inDateLT` with collection count only
        const collectionDetails = result.recordset.reduce((acc, row) => {
          if (row.inDateLT) {
            const collectionDate = row.inDateLT.toISOString().split('T')[0];
            if (!acc[collectionDate]) {
              acc[collectionDate] = { collectionCount: 0 };
            }
            acc[collectionDate].collectionCount += 1;
          }
          return acc;
        }, {});

        const collectionCount = Object.values(collectionDetails).reduce(
          (total, detail) => total + detail.collectionCount,
          0
        );

        const balance = EcciCount - collectionCount;

        resultsArray.push({
          date: formattedDate,
          EcciCount,
          collectionCount,
          balance,
          collectionDetails,
          message: "Data processed for the given date",
        });
      } else {
        resultsArray.push({
          date: formattedDate,
          message: "No data found based on given date",
        });
      }
    }

    res.json(resultsArray);
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};
