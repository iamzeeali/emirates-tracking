const { sql } = require("../db");
const getSqlRequest = require("../utils/dbUtil");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { sendEmailForPasswordChange } = require("../utils/emailServices");
const { sendEmailWithUserCredential } = require("../utils/emailServices");
const { sendEmailToVendorForUserActivation } = require("../utils/emailServices");

// Adding new user
exports.addUser = async (req, res) => {
  try {
    const request = getSqlRequest();
    const userEmail = req.body.email;

    // Check if the email already exists
    const emailCheckQuery = `
          SELECT COUNT(*) as emailCount
          FROM el_3pl_tracking_tb_userDetails_v1
          WHERE email = @email
      `;
    request.input("email", sql.NVarChar, userEmail);
    const emailCheckResult = await request.query(emailCheckQuery);
    const emailCount = emailCheckResult.recordset[0]?.emailCount || 0;

    if (emailCount > 0) {
      return res.status(409).json({ message: "Email already exists" }); // Conflict status code
    }

    // Fetch the max userId and generate the next userId
    const maxIdQuery = `
          SELECT MAX(userId) as maxUId
          FROM el_3pl_tracking_tb_userDetails_v1
      `;
    const result = await request.query(maxIdQuery);
    const maxUId = result.recordset[0]?.maxUId || "U000";

    // Generate the new uId with the prefix 'U'
    const numericPart = parseInt(maxUId.slice(1)) + 1; // Remove the "U" prefix and increment
    const newUId = `U${String(numericPart).padStart(3, "0")}`; // Add the prefix and pad the number

    // Hash the password
    const hashedPassword = await bcrypt.hash(req.body.password, 10);

      // Input parameters
      request.input("userId", sql.NVarChar, newUId); 
      request.input("utmId", sql.NVarChar, req.body.utmId);
      request.input("userTypeId", sql.NVarChar, req.body.userTypeId);
      request.input("fullName", sql.NVarChar, req.body.fullName);
      request.input("password", sql.NVarChar, hashedPassword); 
      request.input("vendorCode", sql.NVarChar, req.body.vendorCode);
      request.input("phoneNumber", sql.NVarChar, req.body.phoneNumber);

    // Insert query
    const query = `
          INSERT INTO el_3pl_tracking_tb_userDetails_v1
          (userId, utmId, userTypeId, fullName, password, vendorCode, email, phoneNumber)
          VALUES 
          (@userId, @utmId, @userTypeId, @fullName, @password, @vendorCode, @email, @phoneNumber);
      `;

    await request.query(query);

    // Send an email to the user with his userId
    // await sendEmailWithUserCredential(userEmail);

    // if (req.body.vendorCode && req.body.vendorCode.trim()) {
    //   const vendorEmailQuery = `
    //             SELECT email FROM
    //             el_3pl_tracking_tb_vendorMaster_v1
    //             WHERE vendorCode = @vendorCode`;

    //   const vendorEmailResult = await request.query(vendorEmailQuery);
      
    //   const vendorEmail = vendorEmailResult.recordset[0].email;

    //   await sendEmailToVendorForUserActivation(vendorEmail, userEmail, newUId );
    // }
    
    return res.status(201).json({ message: "New user added successfully", uId: newUId });
  } catch (error) {
    console.error("Error adding new user:", error);
    return res.status(500).json({ message: "Error adding new user", data: error });
  }
};

// Getting all user
exports.getAllUser = async (req, res) => {
  try {     
    const request = getSqlRequest();
    const query = `
              SELECT *
              FROM el_3pl_tracking_tb_userDetails_v1;
          `;
    const result = await request.query(query);

    if (result.recordset.length > 0) {
      res.json(result.recordset);
    } else {
      res.status(404).send("No data found in the user table");
    }
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};

// Getting user by Id
exports.getUserById = async (req, res) => {
  try {     
    const request = getSqlRequest();
    const { userId } = req.params;
    const query = `
              SELECT *
              FROM el_3pl_tracking_tb_userDetails_v1
              WHERE userId = @userId;
          `;
    request.input("userId", sql.NVarChar, userId);

    const result = await request.query(query);

    if (result.recordset.length > 0) {
      res.json(result.recordset);
    } else {
      res.status(404).send("No data found for this userId");
    }
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).send("Internal Server Error");
  }
};

// Getting all user details after joining 4 tables
exports.getAllUserDetails = async (req, res) => {
  try {
    const request = getSqlRequest();

    // Extract pagination parameters from query
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    // Query to fetch user details with pagination
    const query = `
      SELECT u.userId, u.utmId, u.userTypeId, u.vendorCode, u.fullName, u.email, u.phoneNumber, u.status, utm.userTypeMain, utm.category, ut.userType, v.vendorName
      FROM el_3pl_tracking_tb_userDetails_v1 u
      INNER JOIN el_3pl_tracking_tb_userTypeMain_v1 utm ON u.utmId = utm.utmId
      INNER JOIN el_3pl_tracking_tb_userType_v1 ut ON u.userTypeId = ut.userTypeId
      LEFT JOIN el_3pl_tracking_tb_vendorMaster_v1 v ON u.vendorCode = v.vendorCode
      ORDER BY u.userId
      OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY;
    `;

    // Set query parameters for pagination
    request.input("offset", sql.Int, offset);
    request.input("limit", sql.Int, parseInt(limit, 10));

    const result = await request.query(query);

    if (result.recordset.length > 0) {
      res.json({
        data: result.recordset,
        pagination: {
          currentPage: parseInt(page, 10),
          pageSize: parseInt(limit, 10),
          totalRecords: result.recordset.length, // This could be replaced with a COUNT query if needed
        },
      });
    } else {
      res.status(404).json({ message: "No data found in the user table" });
    }
  } catch (err) {
    console.error("SQL error:", err);
    res.status(500).json({ message: "Internal Server Error", error: err.message });
  }
};

// updating user's status
exports.toggleUserStatus = async (req, res) => {
  try {
    const request = getSqlRequest();

    const { userId } = req.params;

    // Input the userId to identify the user
    request.input("userId", sql.NVarChar, userId);

    // Query to check the current status of the user
    const checkStatusQuery = `
      SELECT status, vendorCode
      FROM el_3pl_tracking_tb_userDetails_v1
      WHERE userId = @userId;
    `;

    const statusResult = await request.query(checkStatusQuery);

    // If no user is found
    if (statusResult.recordset.length === 0) {
      return res
        .status(404)
        .json({ message: "User not found" });
    }

    const currentStatus = statusResult.recordset[0].status;
    const vendorCodeOfUser = statusResult.recordset[0].vendorCode;

    if(req.user.vendorCode === vendorCodeOfUser && req.user.userTypeId === 'UT001' || req.user.userTypeMain === 'Product Team' && req.user.userTypeId === 'UT001'){
      
    // Determine the new status
    const newStatus = currentStatus === 'Active' ? 'Inactive' : 'Active';

    // Update query to toggle the status
    const updateStatusQuery = `
      UPDATE el_3pl_tracking_tb_userDetails_v1
      SET status = @newStatus
      WHERE userId = @userId;
    `;

    // Input the new status
    request.input("newStatus", sql.NVarChar, newStatus);

    const updateResult = await request.query(updateStatusQuery);

    // Check if a row was updated
    if (updateResult.rowsAffected[0] > 0) {
      return res
        .status(200)
        .json({ message: `User status updated to ${newStatus} successfully` });
    } else {
      return res
        .status(404)
        .json({ message: "User not found or no changes made" });
    }
    }else{
      return res.status(403).json({ message: "You are not authorized to activate and deactivate this user"});
    }
  } catch (error) {
    console.error("Error toggling user status:", error);
    return res
      .status(500)
      .json({ message: "Error toggling user status", data: error });
  }
};

// updating user's Type
exports.toggleUserType = async (req, res) => {
  try {
    const request = getSqlRequest();

    const { userId } = req.params;

    // Input the userId to identify the user
    request.input("userId", sql.NVarChar, userId);

    // Query to check the current Type of the user
    const checkTypeQuery = `
      SELECT userTypeId, vendorCode
      FROM el_3pl_tracking_tb_userDetails_v1
      WHERE userId = @userId;
    `;

    const TypeResult = await request.query(checkTypeQuery);

    // If no user is found
    if (TypeResult.recordset.length === 0) {
      return res
        .status(404)
        .json({ message: "User not found" });
    }

    const currentType = TypeResult.recordset[0].userTypeId;
    const vendorCodeOfUser = TypeResult.recordset[0].vendorCode;

    if(req.user.vendorCode === vendorCodeOfUser && req.user.userTypeId === 'UT001' || req.user.userTypeMain === 'Product Team' && req.user.userTypeId === 'UT001'){

    // Determine the new Type
    const newUserTypeId = currentType === 'UT001' ? 'UT002' : 'UT001';

    // Update query to toggle the Type
    const updateTypeQuery = `
      UPDATE el_3pl_tracking_tb_userDetails_v1
      SET userTypeId = @newUserTypeId
      WHERE userId = @userId;
    `;

    // Input the new user Type
    request.input("newUserTypeId", sql.NVarChar, newUserTypeId);

    const updateResult = await request.query(updateTypeQuery);

    // Check if a row was updated
    if (updateResult.rowsAffected[0] > 0) {
      return res
        .status(200)
        .json({ message: `User Type updated to ${newUserTypeId} successfully` });
    } else {
      return res
        .status(404)
        .json({ message: "User not found or no changes made" });
    }
  }else{
    return res.status(403).json({ message: "You are not authorized to change the user role"});
  }
  } catch (error) {
    console.error("Error toggling user Type Id:", error);
    return res
      .status(500)
      .json({ message: "Error toggling user Type Id", data: error });
  }
};

// Api to login user
exports.loginUser = async (req, res) => {
  try {
    const request = getSqlRequest();

    // Add input for SQL query
    request.input("email", sql.NVarChar, req.body.email);

    // SQL query to get user by email
    const query = `
      SELECT u.userId, u.utmId, ut.userTypeMain, u.userTypeId, u.email, u.password, u.vendorCode , u.status
      FROM el_3pl_tracking_tb_userDetails_v1 u
      JOIN el_3pl_tracking_tb_userTypeMain_v1 ut
      ON u.utmId = ut.utmId
      WHERE email = @email
    `;

    const result = await request.query(query);

    // Check if user exists
    if (result.recordset.length === 0) {
      console.log("User not found");
      return res.status(404).json({ message: "User not found" });
    }

    // Check if user's status is active
    if (result.recordset[0].status == "Inactive") {
      return res.status(404).json({ message: "User's status is not active" });
    }

    const storedPassword = result.recordset[0].password;

    // Compare the provided password with the stored hashed password
    const isPasswordMatch = await bcrypt.compare(
      req.body.password,
      storedPassword
    );

    if (isPasswordMatch) {
      // Generate JWT token if password matches
      const token = jwt.sign(
        {
          userId: result.recordset[0].userId,
          utmId: result.recordset[0].utmId,
          userTypeId: result.recordset[0].userTypeId,
          email: result.recordset[0].email,
          vendorCode: result.recordset[0].vendorCode,
          userTypeMain: result.recordset[0].userTypeMain,
        },
        process.env.SECRET_KEY,
        { expiresIn: "1d" }
      );

      // res.cookie('token', token, {httpOnly:true, maxAge:360000});

      res.cookie("token", token, {
        httpOnly: true, // Prevent access via JavaScript
        // secure: true, // Only send over HTTPS (set to false for localhost)
        sameSite: "strict", // Control cookie sharing between sites
        maxAge: 24 * 60 * 60 * 1000, // 1 day
      });

      // Return response with token
      return res.status(200).json({
        message: "Login successful",
        token,
        userId: result.recordset[0].userId,
        utmId: result.recordset[0].utmId,
        userTypeId: result.recordset[0].userTypeId,
        email: result.recordset[0].email,
        vendorCode: result.recordset[0].vendorCode,
        userTypeMain: result.recordset[0].userTypeMain,
      });
    } else {
      console.log("email or Password is incorrect");
      return res
        .status(401)
        .json({ message: "email or Password is incorrect" });
    }
  } catch (error) {
    console.log("Error logging in", error);
    return res.status(500).json({ message: "Error logging in", data: error });
  }
};

// Api to logout user
exports.logoutUser = async (req, res) => {
  try {
    res.clearCookie("token");
    res.json({ message: "Logout successful" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Api to forget password
exports.forgetPassword = async (req, res) => {
  try {
    const request = getSqlRequest();

    // Get the email from the request body
    const { email } = req.body;

    // Check if email was provided or not
    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    // Add input for SQL query
    request.input("email", sql.NVarChar, email);

    // SQL query to check if the user exists based on email
    const checkEmailQuery = `
      SELECT userId, email
      FROM el_3pl_tracking_tb_userDetails_v1
      WHERE email = @email
    `;

    const result = await request.query(checkEmailQuery);

    // Check if user exists
    if (result.recordset.length === 0) {
      return res.status(404).json({ message: "Email not found" });
    }

    const user = result.recordset[0];

    // Generate a token (JWT) with user details
    const token = jwt.sign(
      { userID: user.userID, email: user.email },
      process.env.SECRET_KEY,
      { expiresIn: "5m" }
    );

    // Send an email to the user with the reset password link (including the token)
    await sendEmailForPasswordChange(user.email, token);

    // Respond with success message
    return res
      .status(200)
      .json({ message: "Password reset link sent to email" });
  } catch (error) {
    console.error("Error in forgetPassword", error);
    return res
      .status(500)
      .json({ message: "Internal Server Error", data: error });
  }
};

// API for reset password
exports.resetPassword = async (req, res) => {
  try {
    const {token} = req.params;
    const newPassword = req.body.newPassword;

    // Verify the user using the token
    const verifiedUser = jwt.verify(token, process.env.SECRET_KEY);
    
    const request = getSqlRequest();

    // SQL query to check if the user exists
    request.input("email", sql.NVarChar, verifiedUser.email);

    const checkUserQuery = `
      SELECT email
      FROM el_3pl_tracking_tb_userDetails_v1
      WHERE email = @email
    `;

    const result = await request.query(checkUserQuery);

    if (result.recordset.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // SQL query to update the user's password
    request.input("password", sql.NVarChar, hashedPassword);

    const updatePasswordQuery = `
      UPDATE el_3pl_tracking_tb_userDetails_v1
      SET password = @password
      WHERE email = @email
    `;

    await request.query(updatePasswordQuery);

    return res.status(200).json({ message: "Password reset successfully" });
  } catch (error) {
    console.error("Error in resetPassword", error);

    if (
      error.name === "JsonWebTokenError" ||
      error.name === "TokenExpiredError"
    ) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }

    return res
      .status(500)
      .json({ message: "Internal Server Error", data: error });
  }
};