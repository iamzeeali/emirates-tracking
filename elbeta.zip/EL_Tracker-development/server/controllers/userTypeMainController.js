const { sql } = require("../db");
const getSqlRequest = require("../utils/dbUtil");

// Adding new user type main
exports.addUserTypeMain = async (req, res) => {
  try {
    const request = getSqlRequest();

    // Step 1: Get the current max utmId
    const maxIdQuery = `
      SELECT MAX(utmId) as maxUtmId
      FROM el_3pl_tracking_tb_userTypeMain_v1
    `;

    const result = await request.query(maxIdQuery);
    const maxUtmId = result.recordset[0]?.maxUtmId || "UTM000";

    // Step 2: Generate new utmId
    const numericPart = parseInt(maxUtmId.slice(3)) + 1;
    const newUtmId = `UTM${String(numericPart).padStart(3, "0")}`;

    // Step 3: Insert the new record
    request.input("utmId", sql.NVarChar, newUtmId);
    request.input("userTypeMain", sql.NVarChar, req.body.userTypeMain);
    request.input("category", sql.NVarChar, req.body.category);

    const insertQuery = `
      INSERT INTO el_3pl_tracking_tb_userTypeMain_v1
      (utmId, userTypeMain, category)
      VALUES
      (@utmId, @userTypeMain, @category);
    `;
    await request.query(insertQuery);
    
    return res.status(201).json({ message: "New userTypeMain added successfully", utmId: newUtmId });
  } catch (error) {
    console.error("Error adding new userTypeMain:", error);
    return res.status(500).json({ message: "Error adding new userTypeMain", data: error });
  }
};

// Getting all user type main
exports.getAllUserTypeMain = async (req, res) => {  
    try {
      const request = getSqlRequest();
      const query = `
              SELECT *
              FROM el_3pl_tracking_tb_userTypeMain_v1;
          `;
      const result = await request.query(query);
  
      if (result.recordset.length > 0) {
        res.status(200).json(result.recordset);
      } else {
        res.status(404).send("No data found in the user type main table");
      }
    } catch (err) {
      console.error("SQL error:", err);
      res.status(500).send("Internal Server Error");
    }
};
