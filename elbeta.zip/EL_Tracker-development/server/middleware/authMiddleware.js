// const jwt = require("jsonwebtoken");

// exports.verifyToken = (req, res, next) => {
//   const token = req.headers["authorization"]?.split(" ")[1];

//   if (!token) {
//     console.log("Token not provided");
//     return res.status(401).json({ Message: "Token not provided" });
//   }
//   try {
//     const decodedToken = jwt.verify(token, process.env.SECRET_KEY);
    
//     req.user = decodedToken;
//     next();
//   } catch (error) {
//     console.log("Error verifying token", error);
//     return res
//       .status(500)
//       .json({ message: "Error verifying token", data: error });
//   }
// };


const jwt = require('jsonwebtoken');

exports.verifyToken = (req, res, next) => {
  
  const token = req.cookies.token; // Get token from cookies

  
  if (!token) {
    return res.status(401).json({ message: "Access denied. No token provided." });
  }

  try {
    const decoded = jwt.verify(token, process.env.SECRET_KEY);
    req.user = decoded; // Attach the decoded user information to the request
    next();
  } catch (error) {
    return res.status(400).json({ message: "Invalid token" });
  }
};


