const express = require("express");
const cors = require("cors");
require("dotenv").config();
const helmet = require("helmet");
const xssClean = require("xss-clean");
const { connectToDatabase } = require("./db");
const cookieParser = require("cookie-parser");
const asnRoutes = require("./routes/asnRoutes");
const grnRoutes = require("./routes/grnRoutes");
const vendorRoutes = require("./routes/vendorRoutes");
const poRoutes = require("./routes/poRoutes");
const userTypeRoute = require("./routes/userTypeRoutes");
const userRoute = require("./routes/userRoutes");
const userTypeMainRoute = require("./routes/userTypeMainRoutes");
const { verifyToken } = require("./middleware/authMiddleware")

const app = express();

// Middleware to parse cookies from incoming requests
app.use(cookieParser());

// Middleware to parse JSON bodies
app.use(express.json());

// Use Helmet middleware for basic security headers
app.use(helmet());

// XSS protection middleware
app.use(xssClean());

// app.use(cors());

app.use(cors({
  // origin: "http://localhost:3000", 
  credentials: true, 
}));

// Middleware to secure all routes except unprotected ones
const unprotectedRoutes = [
  "/v1/api/po/status",
  "/v1/api/user/login",
  "/v1/api/vendor/get",
];

app.use((req, res, next) => {
  if (unprotectedRoutes.includes(req.path)) {
    return next();
  }
  verifyToken(req, res, next);
});

// Route definitions
app.use("/v1/api/asn", asnRoutes);
app.use("/v1/api/grn", grnRoutes);
app.use("/v1/api/vendor", vendorRoutes);
app.use("/v1/api/po", poRoutes);
app.use("/v1/api/userType", userTypeRoute);
app.use("/v1/api/user", userRoute);
app.use("/v1/api/userTypeMain", userTypeMainRoute);

// Start the server only after the successful database connection
connectToDatabase()
  .then(() => {
    const PORT = process.env.MSSQL_PORT || 5000;
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error(
      "Failed to start server due to database connection error:",
      err
    );
    process.exit(1); // Exit the process with failure
});
