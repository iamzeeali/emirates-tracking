const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "miteshpradhan97@gmail.com",
    pass: "yliu enkl droc zmdz",
  },
});

async function sendEmail(email, subject, html) {
  const mailOptions = {
    from: "miteshpradhan97@gmail.com",
    to: email,
    subject: subject,
    html: html,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log("Email sent successfully: " + info.response);
    return info;
  } catch (error) {
    console.error("Error sending email: " + error);
    throw error;
  }
}

function sendEmailForPasswordChange(email, token) {
  const subject = "Password Reset";
  const html = `Use this token to <a href="http://localhost:3000/resetPassword/${token}">reset your password</a>`;

  return sendEmail(email, subject, html);
}

function sendEmailWithUserCredential(email) {
  const subject = "Your Credential";
  const html = `You can use this email ${email} for login once admin activate your account`;

  return sendEmail(email, subject, html);
}

function sendEmailToVendorForUserActivation(email, userEmail, newUserId) {
  const subject = "New User For Activation";
  const html = `New user with email ${userEmail} and userId ${newUserId} is created, If user is valid then please activate the account.`;

  return sendEmail(email, subject, html);
}


module.exports = {sendEmailForPasswordChange, 
  sendEmailWithUserCredential,
  sendEmailToVendorForUserActivation
};
